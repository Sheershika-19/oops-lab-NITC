class Logger{
    public enum LogLevel{
        TRACE,
        DEBUG,
        INFO,
        WARN,
        ERROR,
        FATAL,
        NONE
    }

    private static Logger instance=new Logger();
    private static LogLevel currentLogLevel;

    private Logger(){
        this.currentLogLevel=LogLevel.NONE;
    }

    public static Logger getInstance(){
        /*if(instance==null){
        lazy instantiation
            synchronized (System.Logger.class) {
                if(instance==null){
                    instance=new Logger();
                }
            }
        }*/
        return instance;
    }

    public void setLogLevel(LogLevel loglevel){
        this.currentLogLevel=loglevel;
    }
    
    public void logTrace(String message){
        if(currentLogLevel.ordinal() <= LogLevel.TRACE.ordinal()){
            System.out.println("[TRACE]: "+message);
        }
    }

    public void logDebug(String message){
        if(currentLogLevel.ordinal() <= LogLevel.DEBUG.ordinal()){
            System.out.println("[DEBUG]: "+message);
        }
    }

    public void logInfo(String message){
        if(currentLogLevel.ordinal() <= LogLevel.INFO.ordinal()){
            System.out.println("[INFO]: "+message);
        }
    }

    public void logWarn(String message){
        if(currentLogLevel.ordinal() <= LogLevel.WARN.ordinal()){
            System.out.println("[WARN]: "+message);
        }
    }

    public void logError(String message){
        if(currentLogLevel.ordinal() <= LogLevel.ERROR.ordinal()){
            System.out.println("[ERROR]: "+message);
        }
    }

    public void logFatal(String message){
        if(currentLogLevel.ordinal() <= LogLevel.FATAL.ordinal()){
            System.out.println("[FATAL]: "+message);
        }
    }  
}


public class Q1 {
    public static void main(String[] args) {
        Logger logger=Logger.getInstance();
        logger.setLogLevel(Logger.LogLevel.DEBUG);

        logger.logTrace("This is a Trace message.");
        logger.logDebug("This is a Debug message.");
        logger.logInfo("This is a Info message.");
        logger.logWarn("This is a Warn message.");
        logger.logError("This is a Error message.");
        logger.logFatal("This is a Fatal message.");
    }
}