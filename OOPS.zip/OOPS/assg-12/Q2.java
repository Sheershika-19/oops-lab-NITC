import java.util.*;

class SessionManager{
    private Map<String,String> userCredentials;

    private SessionManager(){
        userCredentials=new HashMap<>();
        userCredentials.put("Alice","1234");
        userCredentials.put("Ram","12%4");
        userCredentials.put("Sheershika","1**2");
    }

    private static SessionManager instance=new SessionManager();

    public static SessionManager getInstance(){
        return instance;
    }

    public boolean login(String username,String password){
        if(username==null || password==null){
            System.out.println("Username or password cannot be null.");
            return false;
        }

        String correctPassword=userCredentials.get(username);
        if (correctPassword != null && correctPassword.equals(password)) {
            System.out.println("Login successful for user: " + username);
            return true;
        } else {
            System.out.println("Login failed for user: " + username);
            return false;
        }
    }    

    public boolean addUser(String username, String password) {
        if (userCredentials.containsKey(username)) {
            System.out.println("User already exists: " + username);
            return false;
        }
        userCredentials.put(username, password);
        System.out.println("User added: " + username);
        return true;
    }

    public boolean removeUser(String username) {
        if (userCredentials.remove(username) != null) {
            System.out.println("User removed: " + username);
            return true;
        } else {
            System.out.println("User not found: " + username);
            return false;
        }
    }
}


public class Q2 {
    public static void main(String[] args) {
        SessionManager sessionManager = SessionManager.getInstance();
        sessionManager.login("Alice", "1234");
        sessionManager.login("Ram", "123d"); 
        sessionManager.login("Bob", "non");
        sessionManager.addUser("David", "1256");
        sessionManager.addUser("David", "1256");
        sessionManager.removeUser("David");
        sessionManager.login("David", "1256");
    }
}
