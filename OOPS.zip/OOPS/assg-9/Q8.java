import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Q8 {
    public static void main(String[] args) {
        List <String> words=Arrays.asList("Apple","Aunt","Boy","Car");
        Predicate <String> startswithA=word->word.charAt(0)=='A';
        List<String> filteredWords=words.stream().filter(startswithA).collect(Collectors.toList());
        filteredWords.forEach(System.out::println);
    }
}
