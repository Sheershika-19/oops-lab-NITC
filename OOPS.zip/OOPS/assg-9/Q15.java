import java.util.*;
import java.util.stream.Collectors;

class Customer {
    private String name;
    private String fruitBought;

    public Customer(String name,String fruitBought){
        this.name=name;
        this.fruitBought=fruitBought;
    }

    public String getName(){
        return name;
    }

    public String getfruitBought(){
        return fruitBought;
    }
}

class Fruit{
    private String name;
    private double price;

    public Fruit(String name,double price){
        this.name=name;
        this.price=price;
    }

    public String getName(){
        return name;
    }

    public double getPrice(){
        return price;
    }
}

public class Q15 {
    public static void main(String[] args) {
        List<Customer> customers=Arrays.asList(
            new Customer("Alice","Apple"),
            new Customer("Bob","Banana"),
            new Customer("Charlie", "Apple"),
            new Customer("Jack", "Orange")
        );

        List<Fruit> fruits=Arrays.asList(
            new Fruit("Apple", 24.0),
            new Fruit("Banana", 10.0),
            new Fruit("Orange",20.0)
        );

        Map<String,Double> fruitPrices=fruits.stream().collect(Collectors.toMap(Fruit::getName,Fruit::getPrice));
        Map<String,Long> fruitsCount=customers.stream().collect(Collectors.groupingBy(Customer::getfruitBought,Collectors.counting()));
        Map<String,Double> Amounts=fruitsCount.entrySet().stream().collect(Collectors.toMap(
            Map.Entry::getKey, entry->entry.getValue()*fruitPrices.get(entry.getKey())));
        Amounts.forEach((fruit,price)->System.out.println("Fruit :"+fruit+" Total Price earned :"+price));    
    }
}
