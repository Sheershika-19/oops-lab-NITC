import java.util.*;

public class Q2 {
    public static void main(String[] args) {
        List <String> words=Arrays.asList("Aeroplane","Car","Flat","Home");
        words.forEach(System.out::println);
    }
}
