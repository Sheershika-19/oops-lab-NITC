import java.util.*;

public class Q13 {
    public static void main(String[] args) {
        List<Integer> nums=Arrays.asList(1,2,3,4);
        int product=nums.stream().reduce(1,(a,b)-> a*b);
        System.out.println("Product of Numbers : "+product);
    }
}
