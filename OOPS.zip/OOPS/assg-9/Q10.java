import java.util.*;

class Student {
    private String name;
    private int age;

    public Student(String name,int age){
        this.name=name;
        this.age=age;
    }

    public int getAge(){
        return age;
    }

}

public class Q10 {
    public static void main(String[] args) {
        Student s1=new Student("Alice", 9);
        Student s2=new Student("Bob", 10);
        Student s3=new Student("Joe", 8);
        Student s4=new Student("Krish", 17);
        Student s5=new Student("Ram", 14);
        Student s6=new Student("Pandora", 12);
        Student s7=new Student("Abhi", 14);
        Student s8=new Student("Mounisha", 10);
        Student s9=new Student("Lucky", 16);
        Student s10=new Student("John", 13);
        List<Student> students=Arrays.asList(s1,s2,s3,s4,s5,s6,s7,s8,s9,s10);
        double totalAge=students.stream().mapToInt(Student::getAge).average().orElse(0) ;
       
        System.out.println("Average Age of students :"+totalAge);

    }
}
