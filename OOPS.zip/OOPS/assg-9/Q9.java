import java.util.*;

public class Q9 {
    public static void main(String[] args) {
        List <String> words=Arrays.asList("Book","Pen","Laptop","Table");
        int totalCharacters=words.stream().mapToInt(String::length).sum();
        //int x=words.stream().mapToInt(word->word.chars().sum()).sum();
        System.out.println("Total Characters in the list of words : "+totalCharacters);
    }
}
