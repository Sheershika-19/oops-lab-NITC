import java.util.*;

public class Q6 {
    public static void main(String[] args) {
        List <String> words=Arrays.asList("Apple","Aunt","Boy","Car");
        words.stream().filter(word->(word.length()>0 && word.charAt(0)=='A')).forEach(System.out::println);
    }
}
