import java.util.*;

public class Q5 {
    public static void main(String[] args) {
        List <String> words=Arrays.asList("Book","Pen","Laptop","Table");
        System.out.println("Lengths of the words :");
        words.stream().map(word->word.length()).forEach(System.out::println);
    }
}
