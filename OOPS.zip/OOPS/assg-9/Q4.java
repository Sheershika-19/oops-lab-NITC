import java.util.*;
import java.util.stream.Stream;

public class Q4 {
    public static void main(String[] args) {
        List <String> words=Arrays.asList("Book","Pen","Laptop","Table");
        Stream <String> upperCasewords=words.stream().map(word->word.toUpperCase());
        upperCasewords.forEach(System.out::println);
    }
}
