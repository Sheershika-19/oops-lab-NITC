import java.util.*;

public class Q1 {
    public static void main(String[] args){
        List <String> words=Arrays.asList("Apple","Umbrella","Boy","Car");
        words.forEach(word->System.out.println(word));
    }
}