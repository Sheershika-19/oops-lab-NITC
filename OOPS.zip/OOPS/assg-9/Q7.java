import java.util.*;
import java.util.stream.Collectors;

public class Q7 {
    public static void main(String[] args) {
        List <String> words=Arrays.asList("Apple","Aunt","Boy","Car");
        List <String> filteredWords=words.stream()
                                      .filter(word->(word.length()>0 && word.charAt(0)=='A')).collect(Collectors.toList());
        filteredWords.forEach(System.out::println);
    }
}
