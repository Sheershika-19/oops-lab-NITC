import java.util.*;

public class Q3 {
    public static void main(String[] args) {
        List <String> words=Arrays.asList("Book","Pen","Laptop","Table");
        List <String> upperCasewords=new ArrayList<>();
        words.forEach(word->upperCasewords.add(word.toUpperCase()));
        upperCasewords.forEach(System.out::println);
    }
}
