import java.util.*;

interface Person{
    String getName();
    String getID();
}

interface Student{
    void getSubscribedMealPlans();
    void subscribeMealPlan(MealPLAN mealPlan);
    void unsubscribeMealPlan(MealPLAN mealPlan);
}

interface MealPlan{
    String getPlanName();
    void getMenuItems();
    double getPrice();
}

class MealPLAN implements MealPlan {
    private final String planName;
    private ArrayList<MenuItem> menuItems;
    private double price; 

    public MealPLAN(String planName,double price){
        this.planName=planName;
        menuItems=new ArrayList<>();
        this.price=price;
    }

    @Override
    public String getPlanName(){
        return planName;
    }

    @Override
    public void getMenuItems(){
        System.out.println("Items in Menu plan "+planName);
        for(MenuItem menuitem:menuItems){
            System.out.println("--"+menuitem.getItemName()+" Price :"+menuitem.getPrice());
        }
    }

    @Override
    public double getPrice(){
        return price;
    }

    public void addMenuItem(MenuItem menuitem){
        if(!menuItems.contains(menuitem)){
            menuItems.add(menuitem);
            price+=menuitem.getPrice();
        }
    }
}

class MenuItem{
    private final String itemName;
    private final double price;

    public MenuItem(String itemName,double price){
        this.itemName=itemName;
        this.price=price;
    }

    public String getItemName(){
        return itemName;
    }

    public double getPrice(){
        return price;
    }
}

class StudentImpl implements Person,Student {
    private final String name;
    private final String id;
    ArrayList<MealPLAN> subscribedMealPlans;

    public StudentImpl(String name,String id){
        this.name=name;
        subscribedMealPlans=new ArrayList<>();
        this.id=id;
    }

    @Override
    public String getName(){
        return name;
    }

    @Override
    public String getID(){
        return id;
    }

    @Override
    public void getSubscribedMealPlans(){
        if(!subscribedMealPlans.isEmpty()){
            System.out.println("Meal Plans subscribed by "+name+", ID : "+id);
            for(MealPLAN mealplan : subscribedMealPlans){
                System.out.println("--"+mealplan.getPlanName()+" | Total Price :"+mealplan.getPrice());
            }
        }
        else{
            System.out.println("No Meal plans subscribed.");
        }
    }

    @Override
    public void subscribeMealPlan(MealPLAN mealplan){
        if(!subscribedMealPlans.contains(mealplan)){
           subscribedMealPlans.add(mealplan);
        }
    }

    @Override
    public void unsubscribeMealPlan(MealPLAN mealplan){
        if(subscribedMealPlans.contains(mealplan)){
            subscribedMealPlans.remove(mealplan);
        }
    }
}

class MessController {
    private ArrayList<MealPLAN> mealPlans;

    public MessController(){
        mealPlans=new ArrayList<>();
    }

    public void addMealPlan(MealPLAN mealplan){
        if(!mealPlans.contains(mealplan)){
            mealPlans.add(mealplan);
        }
    }

    public void printSubscriptionStatus(StudentImpl student){
        System.out.println("Subscription status of "+student.getName());
        student.getSubscribedMealPlans();
    }

    public void subscribeStudentToMealPlan(StudentImpl student,MealPLAN mealplan){
        student.subscribeMealPlan(mealplan);
    }

    public void unsubscribeStudentToMealPlan(StudentImpl student,MealPLAN mealplan){
        student.unsubscribeMealPlan(mealplan);
    }
}

public class Q1 {
    public static void main(String[] args) {
        MessController controller = new MessController();
        MealPLAN vegetarianPlan = new MealPLAN("Vegetarian Plan", 10.0);
        vegetarianPlan.addMenuItem(new MenuItem("Salad", 5.0));
        vegetarianPlan.addMenuItem(new MenuItem("Fruit", 3.0));
        controller.addMealPlan(vegetarianPlan);
        StudentImpl student1 = new StudentImpl("Alice", "S001");
        controller.subscribeStudentToMealPlan(student1, vegetarianPlan);
        controller.printSubscriptionStatus(student1);
    }
}