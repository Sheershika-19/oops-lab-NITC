import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;


interface ExecutionMode {
    void executeInSingleThread(List<String> data);
    void executeInMultiThread(List<String> data);
}

abstract class DistributedDataProcessor {
    protected String dataSourceName;
    protected List<String> dataBatch;

    public DistributedDataProcessor(String dataSourceName,List<String> dataBatch){
        this.dataSourceName=dataSourceName;
        this.dataBatch=dataBatch;
    }

    public abstract void loadData();
    public abstract void processData();
    public abstract void processData(Stream<String> realTimeDataStream);
    public abstract void aggregateData(String aggregationType);
}

class StockProcessor extends DistributedDataProcessor implements ExecutionMode {
    public StockProcessor(String dataSourceName,List<String> dataBatch){
        super(dataSourceName, dataBatch);
    }

    @Override
    public void loadData(){
        System.out.println("Loading stock market data from "+dataSourceName);
    }

    @Override
    public void processData(){
        if(dataBatch.size()<100){
            executeInSingleThread(dataBatch);
        }
        else{
            executeInMultiThread(dataBatch);
        }
    }

    @Override
    public void processData(Stream<String> realTimeDataStream){
        System.out.println("Processing real-time stock prices in parallel");
        realTimeDataStream.parallel().forEach(stock->{
            System.out.println("Real-Time processing : "+stock);
        });
    }

    @Override
    public void aggregateData(String aggregationType){
        System.out.println("Aggregating stock data based on "+aggregationType+" trends.");
    }

    @Override
    public void executeInSingleThread(List<String> data){
        System.out.println("Processing data in Single thread...");
        for(String stock : data){
            System.out.println("Proccessing stock : "+stock);
        }
    }

    @Override
    public void executeInMultiThread(List<String> data){
        System.out.println("Processing data in Multi thread...");
        ExecutorService executorService=Executors.newFixedThreadPool(4);
        for (String stock : data) {
            executorService.submit(() -> {
                System.out.println("Multi-threaded processing: " + stock);
            });
        }
        executorService.shutdown();
    }
}

class TransactionProcessor extends DistributedDataProcessor{
    public TransactionProcessor(String dataSourceName,List<String> dataBatch){
        super(dataSourceName, dataBatch);
    }

    @Override
    public void loadData(){
        System.out.println("Loading banking transactions data from "+dataSourceName);
    }

    @Override
    public void processData(){
        System.out.println("Processing banking transactions in batch..");
        for(String txn : dataBatch){
            System.out.println("Processing transaction : "+txn);
        }
    }

    @Override
    public void processData(Stream<String> realTimeDataStream){
        System.out.println("Real-Time is not supported for transactions.");
    }

    @Override
    public void aggregateData(String userId){
        System.out.println("Aggregating transactions for "+userId);
    }

    public void aggregateData(String userId,String riskProfile){
        System.out.println("Aggregating transactions for "+userId+" with risk profile: "+riskProfile);
    }
}

class CryptoProcessor extends DistributedDataProcessor {
    public CryptoProcessor(String dataSourceName,List<String> dataBatch){
        super(dataSourceName, dataBatch);
    } 

    @Override
    public void loadData(){
        System.out.println("Loading cryptocurrency exchange data from "+dataSourceName);
    }

    @Override
    public void processData(){
        System.out.println("Processing cryptocurrency exchange rates in batch..");
        for(String crypto : dataBatch){
            System.out.println("Processing cryptocurrency : "+crypto);
        }
    }

    @Override
    public void processData(Stream<String> realTimeDataStream){
        System.out.println("Real-Time is not supported for cryptocurrency data.");
    }

    @Override
    public void aggregateData(String aggregationType){
        System.out.println("Aggregating cryptocurrency data based on currency: "+aggregationType);
    }
}

public class Q3 {
    public static void main(String[] args) {
        List<String> stockBatch = List.of("AAPL", "GOOGL", "TSLA");
        StockProcessor stockProcessor = new StockProcessor("StockMarket", stockBatch);
        stockProcessor.loadData();
        stockProcessor.processData(); // Batch processing
        stockProcessor.aggregateData("Daily");

        Stream<String> stockStream = Stream.of("AAPL", "AMZN", "TSLA");
        stockProcessor.processData(stockStream); // Real-time processing
// TransactionProcessor instance
        List<String> transactionBatch = List.of("TXN1", "TXN2", "TXN3");
        TransactionProcessor transactionProcessor = new
        TransactionProcessor("BankTransactions", transactionBatch);
        transactionProcessor.loadData();
        transactionProcessor.processData(); // Batch processing
        transactionProcessor.aggregateData("User123", "High Risk");

        List<String> cryptoBatch = List.of("BTC", "ETH", "XRP");
        CryptoProcessor cryptoProcessor = new CryptoProcessor("CryptoExchange",cryptoBatch);
        cryptoProcessor.loadData();
        cryptoProcessor.processData(); // Batch processing
        cryptoProcessor.aggregateData("Currency"); // Currency-based aggregation
    }
}
