abstract class Shipment {
    protected final double weight;
    protected final double distance;

    public Shipment(double weight,double distance){
        this.weight=weight;
        this.distance=distance;
    }

    public abstract double getWeight();

    public abstract double getDistance();
}

class DomesticShipment extends Shipment {
    protected final String transportMode;

    public DomesticShipment(double weight,double distance,String transportMode){
        super(weight,distance);
        this.transportMode=transportMode;
    }

    @Override
    public double getWeight(){
        return weight;
    }

    @Override
    public double getDistance(){
        return distance;
    }
}

class InternationalShipment extends Shipment{
    private final double customDuties;

    public InternationalShipment(double weight,double distance,double customDuties){
        super(weight,distance);
        this.customDuties=customDuties;
    }

    @Override
    public double getWeight(){
        return weight;
    }

    @Override
    public double getDistance(){
        return distance;
    }

    public double getCustomDuties(){
        return customDuties;
    }
}

class ExpressShipment extends DomesticShipment{
    private final double expressFee;

    public ExpressShipment(double weight,double distance,String transportMode,double expressFee){
        super(weight,distance,transportMode);
        this.expressFee=expressFee;
    }

    @Override
    public double getWeight(){
        return weight;
    }

    @Override
    public double getDistance(){
        return distance;
    }

    public double getExpressFee(){
        return expressFee;
    }
}

class ShippingCostCalculator {
    public double calculateCost(DomesticShipment shipment){
        return shipment.getWeight()*1.5+shipment.getDistance()*0.5;
    }

    public double calculateCost(InternationalShipment shipment){
        return shipment.getWeight()*2.0+shipment.getDistance()*0.8+shipment.getCustomDuties();
    }

    public double calculateCost(ExpressShipment shipment){
        return shipment.getWeight()*1.5+shipment.getDistance()*0.5+shipment.getExpressFee();
    }
}

public class Q2 {
    public static void main(String[] args) {
        ShippingCostCalculator calculator=new ShippingCostCalculator();

        DomesticShipment domesticshipment=new DomesticShipment(10, 200, "Road");
        System.out.println("Domestic Shipment Cost : $"+calculator.calculateCost(domesticshipment));

        InternationalShipment internationalshipment=new InternationalShipment(20, 500, 100);
        System.out.println("International Shipment Cost : $"+calculator.calculateCost(internationalshipment));

        ExpressShipment expressshipment=new ExpressShipment(5, 100, "Air", 50);
        System.out.println("Express Shipment Cost : $"+calculator.calculateCost(expressshipment));
    }
}
