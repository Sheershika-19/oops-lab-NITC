abstract class Bank {
    public abstract void calculateInterest();
    public abstract void withdraw(double amount);
    public abstract void deposit(double amount);
    public abstract void getMonthlyStatement();
}

abstract class Account extends Bank {
    protected String accountNumber;
    protected double balance;
    protected String customerName;

    public Account(String accountNumber,double balance,String customerName){
        this.accountNumber=accountNumber;
        this.balance=balance;
        this.customerName=customerName;
    }
}

class SavingsAccount extends Account {
    private static final double interest_rate=0.05;
    private static final double minimum_balance=1000;
    private static final double penalty=50;

    public SavingsAccount(String accountNumber,double balance,String customerName){
        super(accountNumber, balance, customerName);
    }

    @Override
    public void calculateInterest(){
        if(balance > minimum_balance){
            double interest=balance*interest_rate;
            balance+=interest;
        }
    }

    @Override
    public void withdraw(double amount){
        if(balance-amount < minimum_balance){
            balance-=penalty;
            System.out.println("Penalty applied due to insufficient balance.");
        }
        else{
            balance-=amount;
        }
    }

    @Override
    public void deposit(double amount){
        balance+=amount;
    }

    @Override
    public void getMonthlyStatement(){
        System.out.println("Savings Account Monthly Statement :");
        System.out.println("Account Number : "+accountNumber);
        System.out.println("Customer Name : "+customerName);
        System.out.println("Current Balance : "+balance);
        System.out.println("Interest Rate : "+interest_rate*100+"%");
    }
}

class checkingAccount extends Account {
    private static final double transaction_fee=2.0;
    private static final double overdraft_limit=500;
    private static final double overdraft_interest=0.03;

    public checkingAccount(String accountNumber,double balance,String customerName){
        super(accountNumber, balance, customerName);
    }

    @Override
    public void calculateInterest(){
        if(balance < 0){
            double overdraftInterest=Math.abs(balance)*overdraft_interest;
            balance-=overdraftInterest;
        }
    }

    @Override
    public void withdraw(double amount){
        if(balance-amount < 0 && Math.abs(balance-amount) > overdraft_limit){
            System.out.println("Withdrawal declined.Overdraft limit exceeded.");
        }
        else{
            balance-=(amount+transaction_fee);
        }
    }

    @Override
    public void deposit(double amount){
        balance+=amount;
    }

    @Override
    public void getMonthlyStatement(){
        System.out.println("Checking Account Monthly Statement :");
        System.out.println("Account Number : "+accountNumber);
        System.out.println("Customer Name : "+customerName);
        System.out.println("Current Balance : "+balance);
        if(balance < 0){
            System.out.println("Overdraft Amount : "+Math.abs(balance));
        }
    }
}

class InternationalAccount extends Account {
    private static final double conversion_fee=0.02;

    public InternationalAccount(String accountNumber,double balance,String customerName){
        super(accountNumber, balance, customerName);
    }

    @Override
    public void calculateInterest(){
        System.out.println("No interest calculation for International Account.");
    }

    @Override
    public void withdraw(double amount){
        if(balance>=amount){
            balance-=amount;
        }
        else{
            System.out.println("Insufficient funds for withdrawal.");
        }
    }

    @Override
    public void deposit(double amount){
       balance+=amount;
       System.out.println("Deposit of "+amount+" in local currency successful.");
    }

    public void deposit(double amount,String currency){
        double convertedAmount=applyCurrencyConversion(amount,currency);
        balance+=convertedAmount;
        System.out.println("Deposit of "+amount+" "+currency+" converted to local currency and addded to the balance.");
    }

    private double applyCurrencyConversion(double amount,String currency){
        double conversionRate=getConversionRate(currency);
        return amount*conversionRate*(1-conversion_fee);
    }

    private double getConversionRate(String currency){
        switch(currency){
            case "USD":
              return 1.1;
            case "EUR":
              return 1.2;
            case "GBP":
              return 1.3;
            default:
              return 1.0;      
        }
    }

    @Override
    public void getMonthlyStatement(){
        System.out.println("International Account Monthly Statement :");
        System.out.println("Account Number : "+accountNumber);
        System.out.println("Customer Name : "+customerName);
        System.out.println("Current Balance : "+balance);
        System.out.println("Conversion Fee : "+conversion_fee*100+"%");
    }
}

public class Q4 {
    public static void main(String[] args) {
        SavingsAccount savingsaccount=new SavingsAccount("SA123",1500,"Alice");
        savingsaccount.deposit(500);
        savingsaccount.calculateInterest();
        savingsaccount.getMonthlyStatement();
        System.out.println();

        checkingAccount checkingaccount=new checkingAccount("CA123", 200, "Bob");
        checkingaccount.withdraw(50);
        checkingaccount.getMonthlyStatement();
        System.out.println();

        InternationalAccount internationalaccount=new InternationalAccount("IA120",3000,"Charlie");
        internationalaccount.deposit(5000);
        internationalaccount.deposit(1000, "USD");
        internationalaccount.getMonthlyStatement();
    }
}
