import java.util.*;

interface OrderStudents {

    void OrderByRollno(ArrayList<Student> students);

    void OrderByName(ArrayList<Student> students);
}

class Student implements OrderStudents{
    private String Name;
    private int rollNo;
    private String Address;

    public Student(int rollNo,String Name,String Address){
        this.rollNo=rollNo;
        this.Name=Name;
        this.Address=Address;
    }

    public int getRollNo(){
        return rollNo;
    }

    public String getName(){
        return Name;
    }

    @Override
    public void OrderByRollno(ArrayList<Student> students) {
        Collections.sort(students,Comparator.comparingInt(Student::getRollNo));
        //students.sort((a,b)->a.rollNo-b.rollNo);
        System.out.println("//Sorted by RollNo");
        for(Student student : students){
            System.out.println(student.rollNo+" "+student.Name+" "+student.Address);
        }
        System.out.println();
    }

    @Override
    public void OrderByName(ArrayList<Student> students) {
        Collections.sort(students,Comparator.comparing(Student::getName));
        System.out.println("//Sorted by Name");
        for(Student student : students){
            System.out.println(student.rollNo+" "+student.Name+" "+student.Address);
        }
    }

}

public class Q5 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner (System.in);
        ArrayList<Student> students=new ArrayList<>();

        System.out.println("Enter the number of students :");
        int n=scanner.nextInt();
        System.out.println("Enter Roll Number , Name and Address of the students :");
        for(int i=0;i<n;++i){
           int rno=scanner.nextInt();
           String name=scanner.next();
           String address=scanner.next();
           students.add(new Student(rno,name,address));
        }  

        Student s=new Student(0,"","");
        s.OrderByRollno(students);
        s.OrderByName(students);
    }
}
