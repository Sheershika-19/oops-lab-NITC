
import java.util.Scanner;

interface  converter {
     double convertRupees(double money);

     double convertDollars(double money);
    
     double convertPounds(double money);
}

class Bank implements converter {
     
     @Override
     public double convertRupees(double money){
        return money;
     }

     @Override
     public double convertDollars(double money){
        return 70*money;
     }

     @Override
     public double convertPounds(double money){
        return 100*money;
     }
}

public class Q1 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        Bank bank=new Bank();
        System.out.println("Enter the total balance of the credit card in Rupees:");
        double balance=myObj.nextDouble();
        System.out.println("Enter the price of products from shop A(in Rupees) , shop B(in Dollars) and shop C(in Pounds):");
        double pA=myObj.nextDouble();
        double pB=myObj.nextDouble();
        double pC=myObj.nextDouble();
        double remainingBalance=balance-(bank.convertRupees(pA)+bank.convertDollars(pB)+bank.convertPounds(pC));
        if(remainingBalance < 0)
          System.out.println("Insufficient Balance");
        else
          System.out.println("Outstanding Balance : "+remainingBalance);  
        myObj.close();  
    }
}