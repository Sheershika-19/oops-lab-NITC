import java.util.ArrayList;
import java.util.Scanner;

interface Borrowable{
    void checkOut(String username);
    void checkIn();
}

abstract class Book {
    protected int bookID;
    protected String title;
    protected String author;

    public Book(int bookID, String title, String author) {
        this.bookID = bookID;
        this.title = title;
        this.author = author;
    }

    public abstract void displayInfo();
}

class TextBook extends Book implements Borrowable{
    private String status;
    String borrowedUser;
    public TextBook(int bookID, String title, String author) {
        super(bookID, title, author);
        status = "Available";
        borrowedUser = null;
    }
    @Override
    public void checkOut(String username) {
        if (status.equals("Available")) {
            this.status = "Borrowed";
            this.borrowedUser = username;
            System.out.println("Book checked out by " + username);
        } else {
            System.out.println("Book is already borrowed by " + borrowedUser);
        }
    }

    @Override
    public void checkIn() {
        if (status.equals("Borrowed")) {
            this.status = "Available";
            this.borrowedUser = null;
            System.out.println("Book checked in.");
        } else {
            System.out.println("Book is already available.");
        }
    }

    @Override
    public void displayInfo() {
        if (status.equals("Available")) {
            System.out.println("TextBook: " + bookID + ": " + title + ": " + author + ": " + status);
        } else {
            System.out.println("TextBook: " + bookID + ": " + title + ": " + author + ": Borrowed by " + borrowedUser);
        }
    }
}

class ReferenceBook extends Book implements Borrowable {

    public ReferenceBook(int bookID, String title, String author) {
        super(bookID, title, author);
    }

    @Override
    public void checkOut(String username) {
        System.out.println("Cannot be borrowed");
    }

    @Override
    public void checkIn() {
        System.out.println("Invalid");
    }

    @Override
    public void displayInfo() {
        System.out.println("ReferenceBook: " + bookID + ": " + title + ": " + author);
    }
}



public class Q6 {
    private static ArrayList<Book>books = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void addReferenceBook(){
        System.out.println("Enter ID, Title and Author (Line by line)");
        int ID = scanner.nextInt();
        scanner.nextLine(); 
        String Title = scanner.nextLine();
        String Author = scanner.nextLine();
        books.add(new ReferenceBook(ID, Title, Author));
    }

    public static void addTextBook(){
        System.out.println("Enter ID, Title and Author (Line by line)");
        int ID = scanner.nextInt();
        scanner.nextLine();
        String Title = scanner.nextLine();
        String Author = scanner.nextLine();
        books.add(new TextBook(ID, Title, Author));
    }

    public static void checkOut(){
        System.out.print("Enter Book ID: ");
        int checkOutID = scanner.nextInt();
        scanner.nextLine(); 
        Book book = findBookByID(checkOutID);

        if (book != null && book instanceof Borrowable) {
            if(book instanceof TextBook) {
                System.out.print("Enter Username: ");
                String username = scanner.nextLine();
                ((TextBook) book).checkOut(username);
            } 
            else{
                 ((ReferenceBook) book ).checkOut("");
            }
        }
    }

    public static void checkIn(){
        System.out.print("Enter Book ID: ");
        int checkInID = scanner.nextInt();
        scanner.nextLine();  
        Book bookToCheckIn = findBookByID(checkInID);

        if (bookToCheckIn != null && bookToCheckIn instanceof Borrowable) {
           if(bookToCheckIn instanceof TextBook){
            ((TextBook)bookToCheckIn).checkIn();
           }
           else{
            ((ReferenceBook)bookToCheckIn).checkIn();
           }
        }
    }

    public static void listBooks(){
        for (Book book : books) {
            book.displayInfo();
        }
    }

    private static Book findBookByID(int bookID) {
        for (Book book : books) {
            if (book.bookID == bookID) {
                return book;
            }
        }
        System.out.println("Book not found");
        return null;
    }
    
    public static void main(String[] args) {
        
        int choice;
        while (true) { 
            System.out.println("1. Add Reference Book");
            System.out.println("2. Add Text Book");
            System.out.println("3. Check-Out");
            System.out.println("4. Check-In");
            System.out.println("5. List Books");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch(choice){
                case 1:
                    addReferenceBook();
                    break;

                case 2:
                    addTextBook();
                    break;

                case 3:
                    checkOut();
                    break;

                case 4:
                    checkIn();
                    break;

                case 5:
                    listBooks();
                    break;

                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }
    
}