import java.util.*;

interface SortVotes{
    void ascendDisplay();

    void descendDisplay();
}

class ElectionPost implements SortVotes{
    private String nameOfthePost;
    private ArrayList<String> listOfCandidates;
    private ArrayList<String> votesEntered;
    private Map<String,Integer> votesCounter;

    public ElectionPost(String nameOfthePost){
        this.nameOfthePost=nameOfthePost;
        listOfCandidates=new ArrayList<>();
        votesEntered=new ArrayList<>();
        votesCounter=new HashMap<>();
    }

    public void addCandidate(String candidateName){
        listOfCandidates.add(candidateName);
    }

    public void addVotes(String name){
        votesEntered.add(name);
        votesCounter.put(name,votesCounter.getOrDefault(name, 0)+1);
    }

    public void display(){
        System.out.println(nameOfthePost);
        System.out.println(listOfCandidates.size());
        Collections.sort(listOfCandidates);
        for(String name : listOfCandidates)
          System.out.println(name);
    }

    @Override
    public void ascendDisplay(){
        //listOfCandidates.sort(Comparator.comparingInt(candidate -> votesCounter.get(candidate)));
        listOfCandidates.sort((a,b)->votesCounter.get(a)-votesCounter.get(b));
        for(String candidate : listOfCandidates){
            System.out.println(candidate+" - "+votesCounter.get(candidate));
        }
    }

    @Override
    public void descendDisplay(){
        listOfCandidates.sort((a,b)->votesCounter.get(b)-votesCounter.get(a));
        for(String candidate : listOfCandidates){
            System.out.println(candidate+" - "+votesCounter.get(candidate));
        }
    }

}

public class Q4 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);

        System.out.println("Enter the name of the post : ");
        String nameOfthePost=myObj.nextLine();

        ElectionPost electionPost=new ElectionPost(nameOfthePost);

        System.out.println("Enter the number of candidates: ");
        int n=myObj.nextInt();
        myObj.nextLine();

        System.out.println("Enter the names of candidates :");
        for(int i=0;i<n;++i){
            String candidateName=myObj.nextLine();
            electionPost.addCandidate(candidateName);
        }

        System.out.println("Enter the number of votes casted : ");
        int m=myObj.nextInt();
        myObj.nextLine();

        System.out.println("Enter the names of candidates whoc received votes :");
        for(int i=0;i<m;++i){
            String name=myObj.nextLine();
            electionPost.addVotes(name);
        }

        electionPost.display();
        electionPost.ascendDisplay();
        electionPost.descendDisplay();

        myObj.close();
        
    }
}
