
import java.util.Scanner;

interface HDFC {
    double transaction(double balance,double productprice);
}

interface ICICI {
    double transaction(double balance,double productprice);
}

class Flipkart implements HDFC,ICICI {
     double flipkartAccountBalance;

     public Flipkart(){
        flipkartAccountBalance=0;
     }

    @Override 
     public double transaction(double balance,double productprice){
         if(balance < productprice){
             System.out.println("Insufficient Balance for this transaction.");
             return balance;
         }
         else {
            flipkartAccountBalance+=productprice;
            return balance-productprice;
         }
     }

     public double getflipkartBalance(){
        return flipkartAccountBalance;
     }
}

public class Q2 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        Flipkart flipkart=new Flipkart();
        System.out.print("Enter the number of transactions :");
        int n=myObj.nextInt();
        for(int i=0;i<n;++i){
            String bankName=myObj.next();
            double customerBalance=myObj.nextDouble();
            double productPrice=myObj.nextDouble();

            double remainingBalance;

            if(bankName.equals("HDFC")){
                remainingBalance=flipkart.transaction(customerBalance, productPrice);
            }
            else
               remainingBalance=flipkart.transaction(customerBalance, productPrice);
            System.out.println(flipkart.getflipkartBalance()+" "+remainingBalance);   
        }
        myObj.close();
    }
}
