import java.util.*;

interface TaxCalculatable {
    void calculateTax();
}

class Vehicle {
    protected String modelNumber;
    protected double rateBought;
    protected String fuelType;
    protected int numberOfWheels;
    protected double tax;

    public Vehicle(String modelNumber,double rateBought,String fuelType){
        this.modelNumber=modelNumber;
        this.rateBought=rateBought;
        this.fuelType=fuelType;
        this.tax=0;
    }
}

class Car extends Vehicle implements TaxCalculatable{
    private int numberOfPassengers;

    public Car(String modelNumber,double rateBought,String fuelType,int numberOfPassengers){
        super(modelNumber,rateBought,fuelType);
        this.numberOfWheels=4;
        this.numberOfPassengers=numberOfPassengers;
    }
    
    @Override
    public void calculateTax(){
        if(fuelType.equals("petrol"))
          tax=rateBought*0.1*numberOfPassengers*0.5;
        else
          tax=rateBought*0.1*numberOfPassengers*0.4;  
    }

    public double gettax(){
        return tax;
    }
}

class Truck extends Vehicle implements TaxCalculatable{
    private int loadlimit;
    
    public Truck(String modelNumber,double rateBought,String fuelType,int loadlimit){
        super(modelNumber,rateBought,fuelType);
        this.numberOfWheels=6;
        this.loadlimit=loadlimit;
    }

    @Override
    public void calculateTax(){
        if(fuelType.equals("petrol"))
          tax=rateBought*0.1*loadlimit*0.5*0.002;
        else
          tax=rateBought*0.1*loadlimit*0.4*0.002;  
    }

    public double gettax(){
        return tax;
    }

}

public class Q7 {

   private static Scanner sc=new Scanner (System.in);
   private static ArrayList<Vehicle> vehicles=new ArrayList<>();

    public static void addVehicle(){
                sc.nextLine();
                 System.out.println("a.Car");
                 System.out.println("b.Truck");
                 System.out.println("Enter your choice :");
                 char ch=sc.nextLine().charAt(0);
                 System.out.print("ModelNumber :");
                 String mNo=sc.nextLine();
                 System.out.print("Rate :");
                 double rate=sc.nextDouble();
                 sc.nextLine();
                 System.out.print("FuelType(petrol/diesel):");
                 String type=sc.nextLine();
                 if(ch=='a'){
                    System.out.print("Passengers :");
                    int pass=sc.nextInt();
                    Car c=new Car(mNo, rate, type, pass);
                    c.calculateTax();
                    vehicles.add(c);
                 }
                 else{
                    System.out.print("LoadLimit :");
                    int load=sc.nextInt();
                    Truck T=new Truck(mNo, rate, type, load);
                    T.calculateTax();
                    vehicles.add(T);
                 }  
    }

    public static void displayvehicles(){
        vehicles.sort((a,b)->Double.compare(b.tax,a.tax));
        for(Vehicle vehicle : vehicles){
            System.out.print(vehicle.modelNumber+" "+vehicle.fuelType+" ");
            System.out.printf("%.2f\n", vehicle.tax);
        }
    }
    public static void main(String[] args) {
        
        boolean exit=false;

        while(!exit){
           System.out.println("1. Add Vehicle");
           System.out.println("2. Display Vehicles");
           System.out.println("3. Exit"); 
            
           System.out.println("Enter your choice :");
           int choice=sc.nextInt();

           switch (choice){
              case 1 :
                 addVehicle();
                 break;
              case 2:
                 displayvehicles();
                 break;
              case 3:
                exit=true;      
           }
        }
    }
}
