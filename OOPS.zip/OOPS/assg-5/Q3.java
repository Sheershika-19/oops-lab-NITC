
import java.util.Scanner;

interface ShapeArea{
    double Area(double p);
}

class Circle implements ShapeArea{
    @Override
    public double Area(double r){
        return 3.14*r*r;
    }
}

class Square implements ShapeArea{
    @Override
    public double Area(double s){
        return s*s;
    }
}

public class Q3 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);

        String shape=myObj.nextLine();
        double value=myObj.nextDouble();
        double area=0;
        if(shape.equalsIgnoreCase("Circle")){
            area=new Circle().Area(value);
        }
        else if(shape.equalsIgnoreCase("Square")){
            area=new Square().Area(value);
        }
        System.out.printf("%.3f%n",area);
    }
}
