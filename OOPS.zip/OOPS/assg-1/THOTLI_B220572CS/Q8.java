import java.util.Scanner;

public class Q8 {
    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        
        System.out.println("Enter number of rows:");
        int m = myObj.nextInt();
        System.out.println("Enter number of columns:");
        int n = myObj.nextInt();
        
        int[][] arr = new int[m][n];
        
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < n; ++j) {
                arr[i][j] = myObj.nextInt();
            }
        }
        
        // Creating a new matrix to store the transpose
        int[][] transpose = new int[n][m];
        
        // Transposing the matrix
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < n; ++j) {
                transpose[j][i] = arr[i][j];
            }
        }
        
        System.out.println("The transposed matrix is:");
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                System.out.print(transpose[i][j] + " ");
            }
            System.out.println(); // New line after each row
        }
        
       // myObj.close();
    }
}
