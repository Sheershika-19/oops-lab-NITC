import java.util.Scanner;

class Q1{
    public static void main(String[] args) {
         Scanner myObj=new Scanner(System.in);
         System.out.println("Enter a number:");
         int n=myObj.nextInt();
         long factorial=1;
         while(n>0){
            factorial*=n;
            --n;
         }
         System.out.print("Factorial of given number:");
         System.out.print(factorial);
    }
}