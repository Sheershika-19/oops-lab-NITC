import java.util.Arrays;
import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        System.out.println("Enter size of an array:");
        int size=myObj.nextInt();
        int[] arr =new int[size];
        System.out.println("Enter "+size+" elements:");
        for(int i=0;i<size;++i){
            arr[i]=myObj.nextInt();
        }
        Arrays.sort(arr);
        System.out.println("Enter element to be searched:");
        int key=myObj.nextInt();
        int low=0,high=size-1;
        while(low<=high){
            int mid=(low+high)/2;
            if(arr[mid]==key){
                System.out.println("Key found!");
                return ;
            }
            if(arr[mid]>key)
               high=mid-1;
            else
               low=mid+1;              
        }
        System.out.println("Key not found");
    }
       
}
