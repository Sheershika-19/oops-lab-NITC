import java.util.Scanner;

public class Q7 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        System.out.println("Enter two numbers:");
        int x=myObj.nextInt();
        int y=myObj.nextByte();
        System.out.println("Enter operation to be performed:");
        char op=myObj.next().charAt(0);
        switch (op){
            case '+':
               System.out.println(x+y);
               break;
            case '-':
               System.out.println(x-y);
               break;
            case '*':
               System.out.println(x*y);
               break;
            case '/':
               System.out.println(x/y);   
               break;
        }
    }

}
