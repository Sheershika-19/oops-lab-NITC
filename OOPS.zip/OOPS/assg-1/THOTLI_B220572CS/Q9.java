import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Q9 {
    public static void main(String[] args) {
        Scanner myObj =  new Scanner(System.in);
        System.out.print("Enter a word: ");
        String word = myObj.nextLine();
        Map<Character,Integer>freq =  new HashMap<>();

        for(char c: word.toCharArray()){
            freq.put(c,freq.getOrDefault(c, 0)+1);
        }
        System.out.println("Character frequencies:");
        for (Map.Entry<Character, Integer> entry : freq.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        myObj.close();
    }
}