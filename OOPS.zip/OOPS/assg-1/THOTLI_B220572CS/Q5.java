import java.util.Scanner;

public class Q5 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        System.out.println("Enter a string:");
        String str=myObj.nextLine();
        String reversed="";
        for(int i=str.length()-1;i>=0;--i)
           reversed+=str.charAt(i);
        System.out.println(reversed);    
    }
}
