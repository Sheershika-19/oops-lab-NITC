import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        System.out.println("Enter a string:");
        String str=myObj.nextLine();
       for(int i=0;i<str.length();++i) {
         if(str.charAt(i)=='A' || str.charAt(i)=='E' || str.charAt(i)=='I' || str.charAt(i)=='O' || str.charAt(i)=='U'
         || str.charAt(i)=='a' || str.charAt(i)=='e' || str.charAt(i)=='i' || str.charAt(i)=='o' || str.charAt(i)=='u')  {
            System.out.println("Vowel is present in the string");
            return ;
         }   
       }
       System.out.println("Vowel is not present in the string");
    }
}
