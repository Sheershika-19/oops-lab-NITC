import java.util.Scanner;

public class Q10 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        System.out.println("Enter the string1:");
        String str1=myObj.nextLine();
        System.out.println("Enter the string2:");
        String str2=myObj.nextLine();
        System.out.println("Before swapping:");
        System.out.println("str1: "+str1+",str2 :"+str2);
        str1=str1+str2;
        str2=str1.substring(0,str1.length()-str2.length());
        str1=str1.substring(str2.length());
        System.out.println("After swapping:");
        System.out.println("str1: "+str1+",str2 :"+str2); 
        myObj.close();
    }
}
