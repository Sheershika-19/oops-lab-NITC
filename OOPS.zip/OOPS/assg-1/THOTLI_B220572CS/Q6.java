import java.util.Scanner;

public class Q6 {
    public static void main(String[] args) {
        Scanner myobj=new Scanner(System.in);
        System.out.println("Enter a number:");
        int n=myobj.nextInt();
        int p1=0,p2=1;
        if(n==1)
          System.out.print(p1+" ");
        else if(n>=2)
          System.out.print(p1+" "+p2+" ");
        for(int i=3;i<=n;++i){
            int p3=p1+p2;
            System.out.print(p3+" ");
            p1=p2;
            p2=p3;
        }  
    }
}
