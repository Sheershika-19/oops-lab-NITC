import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner myObj= new Scanner(System.in);
        System.out.println("Enter number of students:");
        int n=myObj.nextInt();
        myObj.nextLine();
        String[] names=new String[n];
        int[] rollnos=new int[n];
        for(int i=0;i<n;++i){
            System.out.println("Enter name of "+(i+1)+" student:");
            names[i]=myObj.nextLine();
            System.out.println(names[i]);
           // System.out.println("");
            System.out.println("Enter Rollno. of "+(i+1)+" student:");
            rollnos[i]=myObj.nextInt();
            myObj.nextLine();
        }
        for(int i=0;i<n-1;++i){
            for(int j=0;j<n-i-1;++j){
                if(rollnos[j]>rollnos[j+1]){
                    int t=rollnos[j];
                    rollnos[j]=rollnos[j+1];
                    rollnos[j+1]=t;

                    String tem=names[j];
                    names[j]=names[j+1];
                    names[j+1]=tem;
                }
            }
        }
        System.out.println("Sorted List:");
        for(int i=0;i<n;++i){
            System.out.println(names[i]+" "+rollnos[i]);
        }
    }
}
