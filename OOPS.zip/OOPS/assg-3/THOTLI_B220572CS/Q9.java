public class Q9 {
    public static void main(String[] args) {
        SavingsAccount savingsaccount =new SavingsAccount("10001", 10000.0,5.0);

        savingsaccount.deposit(1000.0);
        savingsaccount.addInterest();
        
        System.out.println("Current Balance :$"+savingsaccount.getBalance());
    }
}

class Account {
    private String accountNumber;
    protected double balance;

    public Account(String accountNumber,double balance){
        this.accountNumber=accountNumber;
        this.balance=balance;
    }

    public void deposit(double amount){
       if(amount>0) {
        balance+=amount;
        System.out.println("Amount deposited Successfully");
       }
       else {
         System.out.println("Invalid Deposit.");
       }
    }

    public double getBalance(){
        return balance;
    }
}

class SavingsAccount extends Account {
    protected double interestRate;

    public SavingsAccount(String accountNumber,double balance,double interestRate){
        super(accountNumber, balance);
        this.interestRate=interestRate;
    }

    public void addInterest(){
        double interest=balance*interestRate/100;
        balance+=interest;
        System.out.println("Interest added :"+ interest);
    }
}


