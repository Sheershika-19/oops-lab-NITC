import java.util.ArrayList;
import java.util.Scanner;

public class Q6 {
    private static Scanner myObj = new Scanner(System.in);
    private static University university = new University("MIT");

    public static void main(String[] args) {
        boolean exit = false;

        while (!exit) {
            System.out.println("\nUniversity Management System");
            System.out.println("1. Add Department");
            System.out.println("2. Add Professor");
            System.out.println("3. Add Student");
            System.out.println("4. Display Departments");
            System.out.println("5. Display Professors");
            System.out.println("6. Display Students");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int op = myObj.nextInt();
            myObj.nextLine(); 

            switch (op) {
                case 1:
                    addDepartment();
                    break;
                case 2:
                    addProfessor();
                    break;
                case 3:
                    addStudent();
                    break;
                case 4:
                    university.displayDepartments();
                    break;
                case 5:
                    displayProfessors();
                    break;
                case 6:
                    displayStudents();
                    break;
                case 7:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addDepartment() {
        System.out.print("Enter department name: ");
        String name = myObj.nextLine();
        Department department = new Department(name);
        university.addDepartment(department);
        System.out.println("Department added successfully.");
    }

    private static void addProfessor() {
        System.out.print("Enter professor name: ");
        String name = myObj.nextLine();
        System.out.print("Enter professor ID: ");
        String id = myObj.nextLine();
        System.out.print("Enter department name: ");
        String deptName = myObj.nextLine();
        Department department = university.getDepartment(deptName);

        if (department != null) {
            Professor professor = new Professor(name, id, department);
            department.addProfessor(professor);
            System.out.println("Professor added successfully.");
        } else {
            System.out.println("Department not found.");
        }
    }

    private static void addStudent() {
        System.out.print("Enter student name: ");
        String name = myObj.nextLine();
        System.out.print("Enter student ID: ");
        String id = myObj.nextLine();
        System.out.print("Enter student major: ");
        String major = myObj.nextLine();
        System.out.print("Enter department name: ");
        String deptName = myObj.nextLine();
        Department department = university.getDepartment(deptName);

        if (department != null) {
            Student student = new Student(name, id, major);
            department.addStudent(student);
            System.out.println("Student added successfully.");
        } else {
            System.out.println("Department not found.");
        }
    }

    private static void displayProfessors() {
        System.out.print("Enter department name: ");
        String deptName = myObj.nextLine();
        Department department = university.getDepartment(deptName);

        if (department != null) {
            department.displayProfessors();
        } else {
            System.out.println("Department not found.");
        }
    }

    private static void displayStudents() {
        System.out.print("Enter department name: ");
        String deptName = myObj.nextLine();
        Department department = university.getDepartment(deptName);

        if (department != null) {
            department.displayStudents();
        } else {
            System.out.println("Department not found.");
        }
    }
}

class University {
    private String name;
    private ArrayList<Department> departments;

    public University(String name) {
        this.name = name;
        this.departments = new ArrayList<>();
    }

    public void addDepartment(Department department) {
        departments.add(department);
    }

    public void displayDepartments() {
        System.out.println("Departments in " + name + ":");
        for (Department dept : departments) {
            System.out.println("- " + dept.getName());
        }
    }

    public Department getDepartment(String name) {
        for (Department dept : departments) {
            if (dept.getName().equalsIgnoreCase(name)) {
                return dept;
            }
        }
        return null;
    }
}

class Department {
    private String name;
    private ArrayList<Professor> professors;
    private ArrayList<Student> students;

    public Department(String name) {
        this.name = name;
        this.professors = new ArrayList<>();
        this.students = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void addProfessor(Professor professor) {
        professors.add(professor);
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void displayProfessors() {
        System.out.println("Professors in " + name + " Department:");
        for (Professor prof : professors) {
            System.out.println("- " + prof.getName());
        }
    }

    public void displayStudents() {
        System.out.println("Students in " + name + " Department:");
        for (Student student : students) {
            System.out.println("- " + student.getName());
        }
    }
}

class Professor {
    private String name;
    private String id;
    private Department department;

    public Professor(String name, String id, Department department) {
        this.name = name;
        this.id = id;
        this.department = department;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public Department getDepartment() {
        return department;
    }
}

class Student {
    private String name;
    private String id;
    private String major;

    public Student(String name, String id, String major) {
        this.name = name;
        this.id = id;
        this.major = major;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getMajor() {
        return major;
    }
}