import java.util.*;

public class Q1 {

    public static  int add(int a,int b){
        return a+b;
    }

    public static  int subtract(int a,int b){
        return a-b;
    }

    public static  int multiply(int a,int b){
        return a*b;
    }

    public static  int divide(int a,int b) throws Exception{
        if(b==0)
          throw new Exception("ArithmeticException: Division by zero handled. Enter a valid argument.");
        return a/b;  
    }

    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        
        try {
            System.out.print("Enter the operation to be performed (+,-,*,/): ");
            char op=myObj.next().charAt(0);
            System.out.print("Enter the first number: ");
            int a=myObj.nextInt();
            System.out.print("Enter the second number: ");
            int b=myObj.nextInt();
            switch(op){
                case '+':
                  System.out.println(add(a,b));
                  break;
                case '-':
                  System.out.println(subtract(a, b));
                  break;
                case '*':
                  System.out.println(multiply(a, b));
                  break;
                case '/':
                  System.out.println(divide(a, b)); 
                  break;     
            }
        } catch (InputMismatchException e) {
            System.out.println("InputMismatchException: Enter valid input digits.");
        }catch(Exception e){
           System.out.println("ArithmeticException: Division by zero handled. Enter a valid argument."); 
          //System.out.println(e);
        }
        
        myObj.close();
    }
}