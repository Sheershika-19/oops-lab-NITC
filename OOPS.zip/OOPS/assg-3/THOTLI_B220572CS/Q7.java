
public class Q7 {
    public static void main(String[] args) {
        SUV suv=new SUV("Toyato","Highlander",2022,"White",5,500.0,true);
        Sedan sedan=new Sedan("Merceded","S-Class",2023,"Black",4,450.0,true);
        Electriccar electriccar=new Electriccar("Tesla", "Model S", 2021, "Red", 4, 400.0, 100);
        Sportscar sportscar=new Sportscar("Ferrari", "488", 2024, "Yellow", 2, 300.0, 210);
        Bus bus = new Bus("Volvo", "7700", 2021, "Blue", 2, "Route 5", true);

        suv.accelerate(30);
        suv.engage4WD();
        suv.turnLeft();

        sedan.activeMassageSeats();
        sedan.brake(10);
        sedan.turnRight();

        electriccar.chargeBattery();
        electriccar.accelerate(60);

        sportscar.accelerate(100);
        sportscar.brake(50);

        bus.openDoors();
        bus.closeDoors();
    }
}

class Vehicle {
    protected String make;
    protected String model;
    protected int year;
    protected String color;
    protected int currentSpeed;

    public Vehicle(String make,String model,int year,String color){
        this.make=make;
        this.model=model;
        this.year=year;
        this.color=color;
        this.currentSpeed=0;
    }
    
    public void accelerate(int increaseSpeed){
        this.currentSpeed+=increaseSpeed;
        System.out.println("Vehicle accelerated to "+this.currentSpeed+" mph.");
    }

    public void brake(int decreaseSpeed){
        this.currentSpeed-=decreaseSpeed;
        if(this.currentSpeed<0)
          this.currentSpeed=0;
        System.out.println("Vehicle slowed to "+this.currentSpeed+" mph.");  
    }

    public void turnLeft(){
        System.out.println("Vehicle turned Left");
    }

    public void turnRight(){
        System.out.println("Vehicle turned Right");
    }
}

class Car extends Vehicle {
    protected int numDoors;
    protected double trunkCapacity;

    public Car(String make,String model,int year,String color,int numDoors,double trunkCapacity){
       super(make,model,year,color);
       this.numDoors=numDoors;
       this.trunkCapacity=trunkCapacity;
    }

    public void openTrunk(){
        System.out.println("Trunk opened with capacity "+trunkCapacity+" liters.");
    }

    public void closeTrunk(){
        System.out.println("Trunk closed.");
    }
}


class Bus extends Vehicle{
    private int numSeats;
    private String routeNumber;
    private  boolean isDoubleDecker;

    public Bus(String make,String model,int year,String color,int numSeats,String routeNumber,boolean isDoubleDecker){
        super(make,model,year,color);
        this.numSeats=numSeats;
        this.routeNumber=routeNumber;
        this.isDoubleDecker=isDoubleDecker;
    }

    public void openDoors(){
        System.out.println("Bus doors opened");
    }

    public void closeDoors(){
        System.out.println("Bus doors closed");
    }
}

class SUV extends Car{
    private boolean offRoadCapability;

    public SUV(String make,String model,int year,String color,int numDoors,double trunkCapacity,boolean offRoadCapability){
        super(make,model,year,color,numDoors,trunkCapacity);
        this.offRoadCapability=offRoadCapability;
    }

    public void engage4WD(){
        if(offRoadCapability)
          System.out.println("4WD engaged for off-road driving.");
        else
          System.out.println("This SUV does not support off-road driving.");  
    }
}

class Sedan extends Car{
    private boolean luxuryInterior;

    public Sedan(String make,String model,int year,String color,int numDoors,double trunkCapacity,boolean luxuryInterior){
        super(make,model,year,color,numDoors,trunkCapacity);
        this.luxuryInterior=luxuryInterior;
    }

    public void activeMassageSeats(){
        if(luxuryInterior)
          System.out.println("Luxury massage seats activated.");
        else
          System.out.println("This sedan does not have luxury massage seats.");  
    }
}

class Electriccar extends Car {
    private int batteryCapacity;

    public Electriccar(String make,String model,int year,String color,int numDoors,double trunkCapacity,int batteryCapacity){
        super(make,model,year,color,numDoors,trunkCapacity);
        this.batteryCapacity=batteryCapacity;
    }

    @Override
    public void accelerate(int increaseSpeed){
        this.currentSpeed+=increaseSpeed;
        System.out.println("Electric car accelerated to "+this.currentSpeed+" mph.");
    }

    public void chargeBattery(){
        System.out.println("Battery charged to "+batteryCapacity+" kwh");
    }
}

class Sportscar extends Car{
    private int topSpeed;

    public Sportscar(String make,String model,int year,String color,int numDoors,double trunkCapacity,int topSpeed){
        super(make,model,year,color,numDoors,trunkCapacity);
        this.topSpeed=topSpeed;
    }

    @Override
    public void accelerate(int increaseSpeed){
        this.currentSpeed+=increaseSpeed;
        if(currentSpeed>topSpeed)
          this.currentSpeed=topSpeed;
        System.out.println("Sports car accelerated to "+this.currentSpeed+" mph.");
    }
}
