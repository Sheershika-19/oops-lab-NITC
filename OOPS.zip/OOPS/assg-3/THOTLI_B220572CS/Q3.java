import java.util.ArrayList;
import java.util.Scanner;

public class Q3 {

    public static ArrayList<Integer> queue = new ArrayList<>();

    public static void enqueue(int x) {
        queue.add(x);
        System.out.print("Success ");
    }

    public static int dequeue() throws Exception {
        if (queue.isEmpty()) {
            throw new Exception("EmptyQueue");
        }
        int x = queue.remove(0);
        return x;
    }

    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        System.out.println("Enter the operations: ");
        String[] ops = myObj.nextLine().split(" ");
        
        for (int i = 0; i < ops.length; ++i) {
            try {
                String op = ops[i];
                switch (op) {
                    case "E":
                        if (i + 1 < ops.length) {
                            int element = Integer.parseInt(ops[i + 1]);
                            enqueue(element);
                            ++i; 
                        } else {
                            System.out.print("Invalid Input ");
                        }
                        break;
                    case "D":
                        int x = dequeue();
                        System.out.print(x+" ");
                        break;
                    default:
                        System.out.print("Invalid operation ");
                        break;
                }
            } catch (Exception e) {
                System.out.print("EmptyQueue ");
            }
        }

        myObj.close();
    }
}
