

public class Q4 {
   String title;
   String author;
   double price;
   int yearPublished;

   public Q4(String title,String author,double price,int yearPublished){
      this.title=title;
      this.author=author;
      this.price=price;
      this.yearPublished=yearPublished;
   }

   public void displayDetails(){
      System.out.println("Title: "+this.title);
      System.out.println("Author: "+this.author);
      System.out.println("Price: "+this.price);
      System.out.println("Year Published: "+this.yearPublished);
      System.out.println();
   }

   public static void main(String[] args) {
       Q4 book1=new Q4("The Great Gatsby","F. Scott Fitzgerald",10.99,1925);
       Q4 book2=new Q4("To Kill a Mockingbird","Harper Lee",7.99,1960);
       Q4 book3=new Q4("1984","George Orwell",8.99,1949);

      book1.displayDetails();
      book2.displayDetails();
      book3.displayDetails();

   } 
}
