
public class Q5 {
    int sensorId;
    String sensorType;
    boolean isActive;

    public Q5(String sensorType){
        this.sensorId=(int)(Math.random()*1000000);
        this.sensorType=sensorType;
        this.isActive=true; 
    }

    public void  Display(){
        System.out.println("sensorId: "+this.sensorId);
        System.out.println("sensorType: "+this.sensorType);
        System.out.println("isActive: "+this.isActive);
        System.out.println();
    }
   public static void main(String[] args) {
       Q5 sensor1=new Q5("temperature");
       Q5 sensor2=new Q5(" humidity");

       sensor1.Display();
       sensor2.Display();
   } 
}
