public class Q8 {
    public static void main(String[] args) {
        Officer officer = new Officer("John Doe", 35, "123 Main St", "555-1234", 5000, "Software Development");
        Manager manager = new Manager("Jane Smith", 40, "456 Elm St", "555-5678", 7000, "Marketing");

        System.out.println("Officer Details:");
        officer.getDetails();
        officer.getSpecialization();
        System.out.println("Annual Salary: $" + officer.calculateAnnualSalary());

        System.out.println("\nManager Details:");
        manager.getDetails();
        manager.getDepartment();
        System.out.println("Annual Salary: $" + manager.calculateAnnualSalary());

        System.out.println("\nUpdating Officer Details:");
        officer.updateDetails("John Doe", 36, "123 Main St", "555-9876", 5500);
        officer.updateSpecialization("Project Management");

        System.out.println("\nUpdating Manager Details:");
        manager.updateDetails("Jane Smith", 41, "456 Elm St", "555-4321", 7500);
        manager.updateDepartment("Sales");

        System.out.println("\nUpdated Officer Details:");
        officer.getDetails();
        officer.getSpecialization();
        System.out.println("Annual Salary: $" + officer.calculateAnnualSalary());

        System.out.println("\nUpdated Manager Details:");
        manager.getDetails();
        manager.getDepartment();
        System.out.println("Annual Salary: $" + manager.calculateAnnualSalary());
    }
}

class Employee {
    protected String name;
    protected int age;
    protected String address;
    protected String phone;
    protected double salary;

    public Employee(String name, int age, String address, String phone, double salary) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.phone = phone;
        this.salary = salary;
    }

    public void getDetails() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("Salary: $" + salary);
    }

    public void updateDetails(String name, int age, String address, String phone, double salary) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.phone = phone;
        this.salary = salary;
        System.out.println("Details updated successfully.");
    }

    public double calculateAnnualSalary() {
        return salary * 12;
    }
}

class Officer extends Employee {
    private String specialization;

    public Officer(String name, int age, String address, String phone, double salary, String specialization) {
        super(name, age, address, phone, salary);
        this.specialization = specialization;
    }

    public void getSpecialization() {
        System.out.println("Specialization: " + specialization);
    }

    public void updateSpecialization(String newSpecialization) {
        this.specialization = newSpecialization;
        System.out.println("Specialization updated successfully.");
    }

    @Override
    public double calculateAnnualSalary() {
        double bonus = 0.1 * salary * 12;
        return super.calculateAnnualSalary() + bonus;
    }
}

class Manager extends Employee {
    private String department;

    public Manager(String name, int age, String address, String phone, double salary, String department) {
        super(name, age, address, phone, salary);
        this.department = department;
    }

    public void getDepartment() {
        System.out.println("Department: " + department);
    }

    public void updateDepartment(String newDepartment) {
        this.department = newDepartment;
        System.out.println("Department updated successfully.");
    }

    @Override
    public double calculateAnnualSalary() {
        double bonus = 0.15 * salary * 12;
        return super.calculateAnnualSalary() + bonus;
    }
}
