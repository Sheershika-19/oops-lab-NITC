import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        try {
            System.out.print("Enter the row_number and column_number :");
            int row_number=myObj.nextInt();
            int column_number=myObj.nextInt();
            System.out.print("Enter the number of movements: ");
            int n=myObj.nextInt();
            myObj.nextLine();
            System.out.println("Enter the movements: ");
            String[] movements=myObj.nextLine().split(" ");
            int rown=row_number;
            int coln=column_number;
            for(int i=0;i<movements.length;i=i+2){
                String dir=movements[i];
                int dirlen=Integer.parseInt(movements[i+1]);
                switch(dir){
                    case "Up" :
                      rown-=dirlen;
                      break;
                    case "Down" :
                     rown+=dirlen;
                     break;
                    case "Left" :
                      coln-=dirlen;
                      break;
                    case "Right" :
                      coln+=dirlen;
                      break;     
                }
                if(rown>8 || rown<1 || coln<1 || coln>8)
                  throw new Exception("Overflow");
            } 
            System.out.println("["+rown+","+coln+"]");
        } catch (Exception e) {
            // System.out.println("Overflow");
            System.out.println(e);
        }
        myObj.close();
    }
}
