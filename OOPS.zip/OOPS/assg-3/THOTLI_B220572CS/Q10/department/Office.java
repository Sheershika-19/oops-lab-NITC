package department;

import company.Employee;
import company.Manager;

public class Office {
    public static void main(String[] args) {
        Employee emp = new Employee("Ram");
        Manager manager = new Manager("Sheershika");
        manager.printName(); 
        System.out.println("Employee's Name: " + emp.getName());
    }
}
