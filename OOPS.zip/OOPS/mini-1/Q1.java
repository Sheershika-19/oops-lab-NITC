import java.util.*;

public class Q1{
    public static void reversee(String str,int len){
          if(len<0)
            return ;
          System.out.print(str.charAt(len));
          reversee(str,len-1);   
    }
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        System.out.println("Enter the string:");
        String str=myObj.nextLine();
        int len=str.length();
        System.out.println("Reversed String:");
        reversee(str,len-1);
    }
}