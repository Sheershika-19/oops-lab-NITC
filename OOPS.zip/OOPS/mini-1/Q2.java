import java.util.*;


public class Q2 {
    private static ArrayList <Member> Members=new ArrayList<>();
    private static ArrayList <Student> Students=new ArrayList<>();
    private static ArrayList <FacultyMember> FacultyMembers=new ArrayList<>();
    private static Scanner myObj =new Scanner(System.in);

    private static void addMember(String name,int Overdudays,String type){
        if(type.equalsIgnoreCase("Student\n")){
            Student newStudent=new Student(name, Overdudays);
            double fine=newStudent.calculateFine();
            Students.add(newStudent);
            Members.add(new Member(name,"Student",fine,Overdudays));
        }
        else{
            FacultyMember newF=new FacultyMember(name, Overdudays);
            double fine=newF.calculateFine();
            FacultyMembers.add(newF);
            Members.add(new Member(name,"Faculty Member",fine,Overdudays));
        }
    }

    private static void displayDetails(){
        for(Member mem:Members){
            System.out.println("Name: "+mem.Name);
            System.out.println("Overdue Days: "+mem.Overduedays);
            System.out.println("Type: "+mem.type);
            System.out.println("Fine: "+mem.fine);
            System.out.println();
        }
    }

    private static void sortmembersbyfine(){
        int n=Members.size();
        for(int i=0;i<n;++i){
            for(int j=0;j<n-i-1;++j){
                if(Members.get(j).fine<Members.get(j+1).fine){
                    Member temp=Members.get(j);
                    Members.set(j,Members.get(j+1));
                    Members.set(j+1,temp);
                }
            }
        }
    }

    public static void main(String[] args) {
       boolean exit=true;
       while(exit){
          System.out.println("Enter the name:");
          String name=myObj.nextLine();
          System.out.println("Enter number of Overdue days:");
          int Overduedays=myObj.nextInt();
          System.out.println("Enter Type:");
          String type=myObj.nextLine();
          myObj.nextLine();
          System.out.print("Do you add another member:(Yes/No)");
          String exx=myObj.nextLine();
         // myObj.nextLine();
          addMember(name,Overduedays,type);
          exit=exx.equalsIgnoreCase("Yes");
         // System.out.println(exit);
         // myObj.nextLine();
       }
       System.out.println("All Members Details:");
       displayDetails();
       sortmembersbyfine();
       System.out.println("Details after sorting:");
       displayDetails();

    }
}

class Member{
    public  String Name;
    public String type;
    public int Overduedays;
    public double fine;

    public Member(String Name,String type,double fine,int Overduedays){
          this.Name=Name;
          this.type=type;
          this.Overduedays=Overduedays;
          this.fine=fine;
    }
}

class Student{
   private String Name;
   private int Overduedays;
   public Student(String Name,int Overduedays){
       this.Name=Name;
       this.Overduedays=Overduedays;
   }

   public double calculateFine(){
    return this.Overduedays*50;
   }
}

class FacultyMember{
    private String Name;
    private int Overduedays;
    public FacultyMember(String Name,int Overduedays){
        this.Name=Name;
        this.Overduedays=Overduedays;
    }

    public double calculateFine(){
        return this.Overduedays*25;
       }
}
