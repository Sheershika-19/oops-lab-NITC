import java.util.*;


public class Q3 {
    private static stoplight light=new stoplight();

    private static void nextstate(){
        String nextt=light.advancestate();
        System.out.println(nextt);
    }
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        String s;
        s="N";
        System.out.println("Stoplight Starting:");
        System.out.println("GREEN");
        //myObj.nextLine();
        while(s.equals("N")){
            
          System.out.println("Enter next operation");
          s=myObj.nextLine();
          if(s.equals("N"))
          nextstate();
        }
        System.out.println("Stoplight stopped");
    }
}

class stoplight{
    public String state;

    public stoplight(){
        this.state="GREEN";
    }

    public String getState(){
        return this.state;
    }

    public String advancestate(){
        if(this.state.equals("GREEN")){
            this.state="YELLOW";
        }
        else if(this.state.equals("YELLOW")){
            this.state="RED";
        }
        else if(this.state.equals("RED")){
            this.state="GREEN";
        }
        return this.state;
    }
}



