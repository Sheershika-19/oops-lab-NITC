class PlatformUser {
    protected String name;
    protected String email;
    protected String userID;

    public PlatformUser(String name,String email,String userID){
        this.name=name;
        this.email=email;
        this.userID=userID;
    }

    public void accessPortal(){
        System.out.println("Portal Access :");
    }
}

class Student extends PlatformUser{
    public Student(String name,String email,String userID){
        super(name,email,userID);
    }

    public void attendLiveSessions(){
        System.out.println("-Attending Live session.");
    }

    public void viewRecordedLectures(){
        System.out.println("-Viewing Online Courses.");
    }

    public void submitAssignment(){
        System.out.println("-Submitting assignments online.");
    }

    @Override 
    public void accessPortal(){
        super.accessPortal();
        viewRecordedLectures();
        attendLiveSessions();
        submitAssignment();
    }
}

class Faculty extends PlatformUser{
    public Faculty(String name,String email,String userID){
        super(name,email,userID);
    }

    public void conductLiveSession(){
        System.out.println("Conducting live session.");
    }

    public void uploadRecordedLecture(){
        System.out.println("Uploading Online course.");
    }

    public void uploadCourseMaterial(){
        System.out.println("Uploading Course Material.");
    }

    public void uploadAssignment(){
        System.out.println("Uploading an online assignment for students.");
    }

    @Override
    public void accessPortal(){
        System.out.println("--Faculty Access--");
        System.out.println("Name: "+name);
        System.out.println("Email: "+email);
        System.out.println("UserID: "+userID);
        System.out.println("\nPortal Access:");
        conductLiveSession();
        uploadCourseMaterial();
        uploadRecordedLecture();
        uploadAssignment(); 
    }
}

public class Q2 {
    public static void main(String[] args) {
        Student student =new Student("Sheershika","Sheershika@gmail.com","B220572CS");
        Faculty faculty=new Faculty("Dr. Smith", "smith@university.com", "FAC001");
        student.accessPortal();
        System.out.println();
        faculty.accessPortal();
    }
}
