abstract class Employee{
    protected String name;
    protected int id;
    protected int leaveDays;

    public Employee(String name,int id,int leaveDays){
        this.name=name;
        this.id=id;
        this.leaveDays=leaveDays;
    }

    public abstract double calculateSalary();

    public double calculateLeaveDeduction(int leaveDays,double deductionrate){
        return leaveDays*deductionrate;
    }
}

class FullTimeEmployee extends Employee{
    private String position;
    private double baseSalary;

    public FullTimeEmployee(String name,int id,int leaveDays,String position,double baseSalary){
        super(name, id, leaveDays);
        this.position=position;
        this.baseSalary=baseSalary;
    }

    public double calculateSalary(String position){
        double deductionRate=1500;
        double salary=baseSalary-calculateLeaveDeduction(leaveDays,deductionRate);
        return salary;
    }

    @Override
    public double calculateSalary(){
        return calculateSalary(this.position);
    }

    public double calculatePerformancebonus(double performancescore){
        double bonus=0.0;
        if(performancescore>90){
           bonus=2000;
        }
        else if(performancescore>80){
            bonus=1000;
        }
        return bonus;
    }
}

class PartTimeEmployee extends Employee{
    private int hoursWorked;
    private double hourlyWage;

    public PartTimeEmployee(String name,int id,int leaveDays,int hoursWorked,double hourlyWage){
        super(name,id,leaveDays);
        this.hourlyWage=hourlyWage;
        this.hoursWorked=hoursWorked;
    }

    public double calculateSalary(int hoursWorked,boolean withbonus){
        double deductionRate=hourlyWage*7+10;
        double salary=(hoursWorked*hourlyWage)-calculateLeaveDeduction(leaveDays, deductionRate);
        if(withbonus && hoursWorked >40){
            salary+=100;
        }

        return salary;
    }

    @Override
    public double calculateSalary(){
        return calculateSalary(this.hoursWorked,false);
    }

    public double calculatePerformancebonus(double performancescore){
        double bonus=0.0;
        if(performancescore>85){
           bonus=500;
        }
        else if(performancescore>75){
            bonus=250;
        }
        return bonus;
    }
}

public class Q3 {
    public static void main(String[] args) {
        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("Alice", 101,2, "Manager",50000); 
        System.out.println("Full-Time Salary (Manager, after leave deduction): " +fullTimeEmployee.calculateSalary("Manager"));
        System.out.println("Full-Time Performance Bonus: " +fullTimeEmployee.calculatePerformancebonus(92));
        PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Bob", 102, 1,45, 20); 
        System.out.println("Part-Time Salary (with bonus, after leave deduction): " +
       partTimeEmployee.calculateSalary(45, true));
       System.out.println("Part-Time Performance Bonus: " +
       partTimeEmployee.calculatePerformancebonus(87));
    }
}
