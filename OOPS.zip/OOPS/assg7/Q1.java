
interface PoweredDevice{
    void powerOn();
    void powerOff();
}

interface NetworkEnabled{
    void connectToNetwork(String networkName);
    void disconnectFromNetwork();
}

class SmartPhone implements PoweredDevice,NetworkEnabled{
    private String model;
    private boolean isPoweredOn;
    private String connectedNetwork;

    public SmartPhone(String model){
        this.model=model;
        this.isPoweredOn=false;
        this.connectedNetwork=null;
    }

    @Override
    public void powerOn(){        
        if(isPoweredOn==false){
            isPoweredOn=true;
            System.out.println(model+" is now powered on.");
        }
        else {
            System.out.println(model+" is already powered on.");
        }
    }

    @Override
    public void powerOff(){
        if(isPoweredOn==true){
            isPoweredOn=false;
            connectedNetwork=null;
            System.out.println(model+" is now powered off.");
        }
        else{
            System.out.println(model+" is already powered off.");
        }
    }

    @Override
    public void connectToNetwork(String network){
        if(isPoweredOn){
            if(connectedNetwork==null){
                connectedNetwork=network;
                System.out.println(model+" is connected to "+network);
            }
            else{
                System.out.println(model+" is already connected to "+connectedNetwork); 
            }
        } 
        else{
            System.out.println("Cannot connect to network."+model+" is powered off.");
        }
    }

    @Override
    public void disconnectFromNetwork(){
        if(isPoweredOn){
            if(connectedNetwork!=null){
                System.out.println(model+" is diconnected from "+connectedNetwork);
                connectedNetwork=null;
            }
            else{
                System.out.println(model+" is not connected to any network.");
            }
        }
        else{
            System.out.println(model+" cannot disconnect from network. It is powered off.");
        }
    }

    @Override
    public String toString(){
        return "\nSmartPhone model: "+model+
                "\nPower Status: "+(isPoweredOn ? "On":"Off")+
                "\nConnected Network: "+(connectedNetwork!=null ? connectedNetwork : "None")+"\n";
    }
}

public class Q1 {
    public static void main(String[] args) {
         SmartPhone phone =new SmartPhone("Realme pro 9"); 

         phone.powerOn();
         phone.connectToNetwork("HOSTEL WIFI");
         System.out.println(phone.toString());
         phone.disconnectFromNetwork();
         phone.powerOff();
         System.out.println(phone.toString());
    }
}