import java.util.Scanner;

public class Q5 {
    static void reverse(String str,int len){
        if(len<0)
          return ;
        System.out.print(str.charAt(len));
        reverse(str,len-1);
    }
    public static void main(String[] args) {
        Scanner myObj=new Scanner (System.in);
        System.out.println("Enter the string:");
        String str=myObj.nextLine();
        int len=str.length();
        System.out.println("Reversed String:");
        reverse(str,len-1); 
        myObj.close();
    }
}