import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner (System.in);
        System.out.println("Enter number of rows:");
        int m=myObj.nextInt();
        myObj.nextLine();
        String[][] arr=new String[m][];
        for(int i=0;i<m;++i){
            System.out.println("Enter number of columns in "+(i+1)+" row:");
            int n=myObj.nextInt();
            myObj.nextLine();
            arr[i]=new String[n];
            for(int j=0;j<n;++j){
                System.out.println("Enter word:");
                //myObj.nextLine();
                arr[i][j]=myObj.nextLine();
                //myObj.nextLine();
            }
        }


        for(int i=0;i<m;++i){
            String s=arr[i][0];
            int k=s.length();
            for(int j=0;j<arr[i].length;++j){
              int p=0;
              while(p<s.length() && p<arr[i][j].length() && s.charAt(p)==arr[i][j].charAt(p)){
                  ++p;
              } 
              k=Math.min(p,k);
            }
            for(int j=0;j<arr[i].length;++j){
                String r=arr[i][j].substring(0,k).toUpperCase()+arr[i][j].substring(k);
                arr[i][j]=r;
            }
        }
        System.out.println("Modified Strings:");
        for(int i=0;i<m;++i){
            for(int j=0;j<arr[i].length;++j){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }  
    }
}




