import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner (System.in);
        System.out.println("Enter the String:");
        String str=myObj.nextLine();
        System.out.println("Enter the substring to be searched:");
        String search=myObj.nextLine();
        int n=str.length();
        for(int i=0;i<n;++i){
            if(str.charAt(i)==search.charAt(0)){
                int j;
                for(j=0;j<search.length();++j){
                    if(i+j>=n || search.charAt(j)!=str.charAt(i+j))
                       break;
                }
                if(j==search.length()){
                    System.out.println("True");
                    return;
                }                
            }
        }
        System.out.println("False");
        myObj.close();
    }
}
