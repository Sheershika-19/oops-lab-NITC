
import java.util.ArrayList;
import java.util.Scanner;

public class Q12 {
    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        TaskManager taskManager = new TaskManager();

        while (true) {
            System.out.println("\nSelect the operation:");
            System.out.println("1. Add Task");
            System.out.println("2. Process Task");
            System.out.println("3. Display Tasks");
            System.out.println("4. Exit");
            System.out.print("Your choice: ");
            int choice = myObj.nextInt();
            myObj.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter task priority and description: ");
                    int priority = myObj.nextInt();
                    myObj.nextLine(); 
                    String description = myObj.nextLine();
                    taskManager.addTask(priority, description);
                    break;
                case 2:
                    taskManager.processTask();
                    break;
                case 3:
                    taskManager.displayTasks();
                    break;
                case 4:
                    myObj.close();
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}

class Task{
  int priority;
  String description;
  public Task(int priority, String description) {
      this.priority = priority;
      this.description = description;
  }

  public int getPriority() {
      return priority;
  }

  public String getDescription() {
      return description;
  }
}

class TaskManager{
   private ArrayList<Task> tasks = new ArrayList<>();
  

   public void addTask(int priority, String description) {
      Task newTask = new Task(priority, description);
      tasks.add(newTask);
      sortTasksByPriority();
  }

  private void sortTasksByPriority() {
      tasks.sort((task1, task2) -> Integer.compare(task1.getPriority(), task2.getPriority()));
  }

  public void processTask() {
      if (!tasks.isEmpty()) {
          Task taskToProcess = tasks.remove(0);
      } else {
          System.out.println("No tasks to process.");
      }
  }

  public void displayTasks() {
      if (!tasks.isEmpty()) {
          System.out.println("Current Tasks:");
          for (Task task : tasks) {
              System.out.println(task.getDescription());
          }
      } else {
          System.out.println("No tasks in the queue.");
      }
  }

}

