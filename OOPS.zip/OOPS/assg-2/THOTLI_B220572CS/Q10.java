import java.util.ArrayList;
import java.util.Scanner;

public class Q10 {
    private static Library library=new Library();
    private static Scanner myObj=new Scanner(System.in); 

    private static void addBook(){
        System.out.print("Enter the Book id: ");
        int id = myObj.nextInt();
        myObj.nextLine();  // Consume newline
        System.out.print("Enter the Book title: ");
        String title = myObj.nextLine();
        System.out.print("Enter the Book author: ");
        String author = myObj.nextLine();
        library.addBook(id, title, author);
    }

    private static void removeBook() {
        System.out.print("Enter the id  ");
        int id = myObj.nextInt();
        myObj.nextLine(); 
        library.removeBook(id);
    }

    private static void listAllBooks() {
        library.listAllBooks();
    }

    private static void findBook() {
        System.out.print("Enter the title  ");
        String title = myObj.nextLine();
        library.findBook(title);
    }

    public static void main(String[] args) {
        boolean exit=false;
        while(!exit){
            System.out.println("Select the operation:");
            int op=myObj.nextInt();
            myObj.nextLine();
            switch(op){
                case 1:
                  addBook();
                  break;
                case 2:
                  removeBook();
                  break;
                case 3:
                  listAllBooks();
                  break;
                case 4:
                  findBook();
                  break;
                case 5:
                  exit=true;
                  break;    
            }
        }
    }

    
}

class Book {
    private int id;
    private String title;
    private String author;

    public Book (int id,String title,String author){
        this.id=id;
        this.title=title;
        this.author=author;
    }

    public int getID(){
        return id;
    }

    public String getTitle(){
        return title;
    }

    public String getAuthor(){
        return author;
    }

    @Override
    public String toString(){
        return id+", "+title+", "+author;
    }
}



class Library{
    public ArrayList<Book> books=new ArrayList<>();
    
    public void addBook (int id,String title,String author){
        books.add(new Book(id,title,author));    
    }

    public void removeBook(int id){
        for(Book book:books){
            if(book.getID()==id){
                books.remove(book);
                return ;
            }           
        }
    }

    public void listAllBooks(){
        for(Book book:books)
          System.out.println(book.getTitle());
    }
  
    public void findBook (String name){
        for(Book book:books){
            if(book.getTitle().equalsIgnoreCase(name))
               System.out.println(book);            
        }
    }
}