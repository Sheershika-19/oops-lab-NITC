import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner myObj=new Scanner (System.in);
        System.out.println("Enter the string:");
        String str=myObj.nextLine();
        System.out.println("Enter the word to replace:");
        String deletee=myObj.nextLine();
        System.out.println("Enter the word to be replaced with:");
        String replacee=myObj.nextLine();

        String ans="";
        for(int i=0;i<str.length();++i){
            int k=0;
            if(str.charAt(i)==deletee.charAt(k) && i+deletee.length()<=str.length()){
                int j=0;
                for(j=i;j<i+deletee.length();++j){
                    if(str.charAt(j)!=deletee.charAt(k))
                      break;
                    else
                      ++k;  
                }
                if(j==i+deletee.length()){
                    ans+=replacee;
                    i=j-1;
                }
                else
                   ans+=str.charAt(i);
            }
            else
                ans+=str.charAt(i);
        }  
        System.out.println("Modified String:");
        System.err.println(ans);
        myObj.close();
    }
}
