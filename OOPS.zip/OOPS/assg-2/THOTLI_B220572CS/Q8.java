import java.util.Scanner;


public class Q8 {
    public static void main(String[] args){
        Scanner myObj=new Scanner (System.in);
        Teacher[] Teachers={
            new Teacher(1,"Mr. Sabu"),
            new Teacher(2,"Ms. Jaya"),
            new Teacher(3,"Dr. Babu"),
        } ;

        System.out.print("Enter the number of students to add:");
        int n=myObj.nextInt();
        myObj.nextLine();

        Student[] students=new Student[n];
        for(int i=0;i<n;++i){
           System.out.print("Enter roll number:");
           int rn=myObj.nextInt();
           myObj.nextLine();
           System.out.print("Enter full name:");
           String name=myObj.nextLine();
          
           System.out.print("Enter height:");
           double ht=myObj.nextDouble();
          
           System.out.print("Enter weight:");
           double wt=myObj.nextDouble();
           
           System.out.println("Available teachers:");
           System.out.println("1. Mr. Sabu");
           System.out.println("2. Ms. Jaya");
           System.out.println("3. Dr. Babu");

           System.out.print("Choose a teacher by ID:");
           int tid=myObj.nextInt();

           Teacher assignedTeacher=null;
           for(int j=0;j<Teachers.length;++j){
              if(Teachers[j].teacherId==tid){
                assignedTeacher=Teachers[j];
                break;
              }
           }

           students[i]=new Student(rn,name,ht,wt,assignedTeacher);
           System.out.println(name+" has been added to the student list.");

        }

        System.out.println("All students sorted by height:");
        //bubble sort 
        for(int i=0;i<n-1;++i){
            for(int j=0;j<n-i-1;++j){
                if(students[j].height>students[j+1].height){
                    Student temp=students[j];
                    students[j]=students[j+1];
                    students[j+1]=temp;
                }
            }
        }

        for(int i=0;i<n;++i){
            System.out.println("Roll Number: "+students[i].rollNumber);
            System.out.println("Full Name: "+students[i].Name);
            System.out.println("Height: "+students[i].height);
            System.out.println("Weight: "+students[i].weight);
            System.out.println("Assigned Teacher: "+students[i].assignedTeacher.teacherName);  
        }
        System.out.println("Student Names and their Assigned Teachers:");
        for(int i=0;i<n;++i){
            System.out.println(students[i].Name+" - "+students[i].assignedTeacher.teacherName);
        }
        myObj.close();
    }
}

class Teacher {
    int teacherId;
    String teacherName;

    public Teacher(int teacherId,String teacherName){
        this.teacherId=teacherId;
        this.teacherName=teacherName;
    }
}

class Student{
    int rollNumber;
    String Name;
    double height;
    double weight;
    Teacher assignedTeacher;

    public Student(int rollNumber,String Name,double height,double weight,Teacher assignedTeacher){
        this.rollNumber=rollNumber;
        this.Name=Name;
        this.height=height;
        this.weight=weight;
        this.assignedTeacher=assignedTeacher;
    }
}