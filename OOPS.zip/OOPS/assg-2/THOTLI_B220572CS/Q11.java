import java.util.HashSet;
import java.util.Scanner;

public class Q11 {
    private static Scanner myObj=new Scanner(System.in);
    private static HashSet<Integer> Ids=new HashSet<>();  

    private static void addEmployeeId(){
        System.out.println("Enter the Id");
        int id=myObj.nextInt();
        myObj.nextLine();
        if(Ids.contains(id)){
            System.out.println("Already present");
        }
        else{
            Ids.add(id);
            System.out.println("Successfully added");
        }
    }

    public static void removeEmployeeId(){
        System.out.println("Enter the Id");
        int id=myObj.nextInt();
        myObj.nextLine(); 
        if(Ids.contains(id)){
            Ids.remove(id);
            System.out.println("Successfully removed");
        }
        else{
            System.out.println("Not present");
        }
    }

    public static void displayEmployeeIds(){
        for(int id:Ids)
         System.out.println(id);
    }

    public static void main(String[] args) {      
        boolean exit=false;
        while(!exit){
            System.out.println("Select the operation:");
            int op=myObj.nextInt();
            myObj.nextLine();
            switch(op){
                case 1:
                  addEmployeeId();
                  break;
                case 2:
                  removeEmployeeId();
                  break;
                case 3:
                  displayEmployeeIds();
                  break;
                 case 4:
                   exit=true;      
            }
        }
    }
}
