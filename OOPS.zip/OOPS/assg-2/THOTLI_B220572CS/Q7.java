import java.util.HashMap;
import java.util.Scanner;

public class Q7 {
    private static HashMap<Integer,Account> accounts=new HashMap<>();
    private static int nextAccountNumber=1001;
    private static Scanner myObj=new Scanner (System.in);

    public static void main(String[] args) {
        boolean exit=false;
        while(!exit){
          System.out.println("Banking System Menu:");  
          System.out.println("1. Create a new account");
          System.out.println("2. Deposit money");
          System.out.println("3. Withdraw money");
          System.out.println("4. Check balance");
          System.out.println("5. Exit");  
          System.out.print("Choose an option:");
          int op;
          op=myObj.nextInt();
          myObj.nextLine(); 
          switch(op){
            case 1:  
              createAccount();
              break;
            case 2:
             depositMoney();
             break; 
           case 3:
             withdrawMoney();
             break;
           case 4:
             checkBalance();
             break;
           case 5:
             exit=true;
             System.out.println("Exiting the banking system. Goodbye!");        
             break;
          }             
        }
    }

    private static void createAccount(){
        System.out.print("Enter account holder's name:");
        String name=myObj.nextLine();
        System.out.print("Enter initial deposit amount:");
        double deposit=myObj.nextDouble();
        myObj.nextLine(); 
        Account newAccount=new Account(nextAccountNumber,name,deposit);
        accounts.put(nextAccountNumber,newAccount);
        System.out.println("Account created successfully!");
        System.out.println("Account Number: "+nextAccountNumber);
        System.out.println("Account Holder: "+name);
        System.out.println("Balance: "+deposit);
        nextAccountNumber++;
   }

   private static void depositMoney(){
        System.out.print("Enter account number: ");
        int an=myObj.nextInt();
        System.out.print("Enter deposit amount: ");
        double dp=myObj.nextDouble();
        myObj.nextLine(); 
        Account cur=accounts.get(an);
        if(cur!=null){
           cur.deposit(dp);
           System.out.println("Updated account details:");
           System.out.println("Account Number: "+an);
           System.out.println("Account Holder: "+cur.getAccountHolder());
           System.out.println("Balance: "+cur.getBalance());
        }
   }

   private static void withdrawMoney(){
       System.out.print("Enter account number: ");
       int an=myObj.nextInt();
       System.out.print("Enter withdrawal amount: ");
       double dp=myObj.nextDouble();
       myObj.nextLine(); 
       Account cur=accounts.get(an);
       if(cur!=null){
          cur.withdraw(dp);
          System.out.println("Updated account details:");
          System.out.println("Account Number: "+an);
          System.out.println("Account Holder: "+cur.getAccountHolder());
          System.out.println("Balance: "+cur.getBalance());
       }
   }

   private static void checkBalance(){
       System.out.print("Enter account number: ");
       int an=myObj.nextInt();
       myObj.nextLine(); 
       Account cur=accounts.get(an);
       if(cur!=null){
          System.out.println("Account Number: "+an);
          System.out.println("Account Holder: "+cur.getAccountHolder());
          System.out.println("Balance: "+cur.getBalance());
       }
   }
}

class Account{
    private int AccountNumber;
    private String AccountHolder;
    private double balance;

    public Account(int AccountNumber,String AccountHolder,double deposit){
        this.AccountNumber=AccountNumber;
        this.AccountHolder=AccountHolder;
        this.balance=deposit;
    }

    public int getAccountNumber(){
        return AccountNumber;
    }

    public String getAccountHolder(){
        return AccountHolder;
    }

    public double getBalance(){
        return balance;
    }

    public void deposit(double amount){
        balance+=amount;
        System.out.println("Successfully deposited "+amount);
    }

    public void withdraw(double amount){
        balance-=amount;
        System.out.println("Successfully withdrew $"+amount);
    }


}