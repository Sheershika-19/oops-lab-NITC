import java.util.Scanner;

public class Q4 {

   public static int f(int[] arr,int i){
        if(i==0)
          return arr[0];
        return Math.max(arr[i],f(arr,i-1));  
    }
    public static void main(String[] args) {
        Scanner myObj=new Scanner (System.in);
        System.out.println("Enter size of an array:");
        int n=myObj.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter "+n+" elements:");
        for(int i=0;i<n;++i){
            arr[i]=myObj.nextInt();
        }
        int maxi=f(arr,n-1);
        System.out.println("Maximum element: "+maxi);
        myObj.close();
    }
}