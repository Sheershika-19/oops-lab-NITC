import java.util.Scanner;

public class Q6 {
    String name;
    boolean guest;
    boolean vegetarian;

    public Q6(String name,boolean guest,boolean vegetarian){
        this.name=name;
        this.guest=guest;
        this.vegetarian=vegetarian;
    }
     
    public void billing(int days){
        double bill=0;
        if(vegetarian)
          bill+=100*days;
        else
          bill+=120*days;
        if(guest){
            double extra=0.1*bill;
            bill+=extra;
        }
        System.out.println("Total bill for "+name+" is:"+bill);
    }

   public static void main(String[] args) {
       Scanner myObj=new Scanner (System.in);
       System.out.print("Enter name:");
       String name=myObj.nextLine();
       System.out.print("Are you a guest? (yes/no):");
       String gb=myObj.nextLine();
       boolean guest=gb.equalsIgnoreCase("yes");
       System.out.print("Are you vegetarian? (yes/no):");
       String vb=myObj.nextLine();
       boolean vegetarian=vb.equalsIgnoreCase("yes");
       System.out.print("Enter the number of days:");
       int days=myObj.nextInt();
       Q6 person =new Q6(name,guest,vegetarian);
       person.billing(days);
       myObj.close();
   } 
}
