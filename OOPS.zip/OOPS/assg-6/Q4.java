class Customer {
    protected String name;
    protected double foodPrice;
    protected final double deliveryCost=5;

    public Customer(String name,double foodPrice){
        this.name=name;
        this.foodPrice=foodPrice;
    }

    public double TotalCost(){
        return foodPrice+deliveryCost;
    }

    public void displayOrderdetails(){
        System.out.println("Customer :"+name);
        System.out.println("Total Order Cost : $"+TotalCost());
        System.out.println();
    }
}

class PremiumCustomer extends Customer{
    
    public PremiumCustomer(String name,double foodPrice){
        super(name,foodPrice);
    }

    @Override
    public double TotalCost(){
        return foodPrice;
    }

}

public class Q4 {
    public static void main(String[] args) {
    
        Customer c1=new Customer("Alice",20.0); 
        c1.displayOrderdetails();
        
        PremiumCustomer p1=new PremiumCustomer("Bob", 30.0);
        p1.displayOrderdetails();

    }
}
