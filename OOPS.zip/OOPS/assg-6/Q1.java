class ecommerce{

    public static double calculateTotalPrice(double singleItemPrice,int quantity){
        return singleItemPrice*quantity;
    }

    public static double calculateTotalPrice(double[] prices,int[] quantites){
        double totalPrice=0;
        for(int i=0;i<prices.length;++i){
            totalPrice+=prices[i]*quantites[i];
        }
        return totalPrice;
    }

    public static double calculateTotalPrice(double totalPrice,double discountPercentage){
        double discountedPrice=totalPrice-(totalPrice*discountPercentage/100);
        return discountedPrice;
    }
}

public class Q1 {
    public static void main(String[] args) {
        
        double singleItemPrice=ecommerce.calculateTotalPrice(100.0, 5);
        System.out.printf("Total price of single Item : %.2f Rs.\n",singleItemPrice);

        double[] prices={12.3,14.5,19.7};
        int[] quantites={2,3,4};
        double MultipleItemsPrice=ecommerce.calculateTotalPrice(prices, quantites);
        System.out.printf("Total price of Multiple items : %.2f Rs.\n",MultipleItemsPrice);

        double discountedPrice=ecommerce.calculateTotalPrice(MultipleItemsPrice,14.0);
        System.out.printf("Final Discounted Price : %.2f RS.\n",discountedPrice);
    }
}