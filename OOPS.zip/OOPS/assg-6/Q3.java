
class Student {
    protected String name;

    public Student(String name){
        this.name=name;
    }

    public String formatName(){
        String reversed="";
        for(int i=name.length()-1;i>=0;--i)
          reversed+=name.charAt(i);
        return reversed;
    }

    public int countVowels(){
        int count=0;
        for(int i=0;i<name.length();++i){
           if(name.charAt(i)=='a' || name.charAt(i)=='e' ||name.charAt(i)=='i' ||name.charAt(i)=='o' ||name.charAt(i)=='u' ||
           name.charAt(i)=='A' ||name.charAt(i)=='E' ||name.charAt(i)=='I' ||name.charAt(i)=='O' ||name.charAt(i)=='U'  )
              ++count;
        }
        return count;
    }

    public boolean palindromeCheck(){
        String reversed=formatName();
        return name.equalsIgnoreCase(reversed);
    }
}

class NITCalicutStudent extends Student{
   private  String department;
   private String rollNumber;

    public NITCalicutStudent(String name,String department,String rollNumber){
        super(name);
        this.department=department;
        this.rollNumber=rollNumber;
    }

    @Override
    public String formatName(){
        return super.formatName()+" (NIT CALICUT) ";
    }

    public String getDepartment(){
        return department;
    }

    public String getrollNumber(){
        return rollNumber;
    }

    public void displayDetails(){
        System.out.println("Student Details: " + name + " - Department: " + department + ", Roll Number: " + rollNumber);
    }
}

public class Q3 {
    public static void main(String[] args) {
        Student student1 = new Student("Rajesh");
        System.out.println("For a Student with name \"" + student1.name + "\"");
        System.out.println("Reversed Name: " + student1.formatName());
        System.out.println("Vowel Count: " + student1.countVowels());
        System.out.println("Palindrome Check: " + student1.palindromeCheck());
        System.out.println();

        NITCalicutStudent nitStudent = new NITCalicutStudent("Rajesh", "Computer Science", "CS123");
        System.out.println("For a NITCalicutStudent with name \"" + nitStudent.name + "\", department \"" + nitStudent.getDepartment() + "\", and roll number \"" + nitStudent.getrollNumber() + "\":");
        System.out.println("Reversed Name with Tag: " + nitStudent.formatName());
        System.out.println("Vowel Count: " + nitStudent.countVowels());
        System.out.println("Palindrome Check: " + nitStudent.palindromeCheck());
        nitStudent.displayDetails();
    }
}
