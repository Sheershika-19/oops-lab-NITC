class Booking{

    public void bookTransport(String flightNumber,String departureCity,String ArrivalCity){
        System.out.println("Flight ticket Booked!");
        System.out.println("Flight Number :"+flightNumber);
        System.out.println("Arrival City :"+ArrivalCity);
        System.out.println("Departure City :"+departureCity);
        System.out.println("");
    }

    public void bookTransport(int trainNumber,String classOfService){
        System.out.println("Train ticket Booked!");
        System.out.println("Train Number :"+trainNumber);
        System.out.println("Class of Service :"+classOfService);
        System.out.println("");
    }

    public void bookTransport(String pickupLocation,String destination){
        System.out.println("Cab booked!");
        System.out.println("Pick Up Location :"+pickupLocation);
        System.out.println("Destination :"+destination);
        System.out.println("");
    }

    public void bookTransport(String pickupLocation,String destination,int passengers){
        System.out.println("Cab booked!");
        System.out.println("Pick Up Location :"+pickupLocation);
        System.out.println("Destination :"+destination);
        System.out.println("Number of Passengers :"+passengers);
        System.out.println("");
    }
}

public class Q2 {
   public static void main(String[] args) {
       Booking booking =new Booking();

       booking.bookTransport("AI202", "New York", "Los Angeles");
       booking.bookTransport(12345, "Business");
       booking.bookTransport("Central Park", "Times Square");
       booking.bookTransport("Central Park", "Times Square", 3);
   } 
}
