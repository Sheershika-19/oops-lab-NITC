import java.util.ArrayList;
import java.util.List;

class product {
    private String name;

    public product(String name){
        this.name=name;
    }

    public String getName(){
        return name;
    }

    @Override
    public String toString(){
        return "Product :"+name;
    }
}

class Electronics extends product {
   private int warrantyPeriod ;

   public Electronics(String name,int warrantyPeriod){
    super(name);
    this.warrantyPeriod=warrantyPeriod;
   }

   public int getWarrantyperiod(){
    return warrantyPeriod;
   }

   @Override
   public String toString(){
    return super.toString()+" ,"+"Warranty Period :"+warrantyPeriod+" months";
   }
}

class Clothing extends product{
    private String size;

    public Clothing(String name,String size){
        super(name);
        this.size=size;
    } 

    public String getSize(){
        return size;
    }

    @Override
    public String toString(){
       return super.toString()+" ,"+"Size :"+size;
    }
}

class Inventory <T extends product>{
    private List<T> products;

    public Inventory(){
        products=new ArrayList<>();
    }

    public void addProduct(T product){
        products.add(product);
        System.out.println(product.getName()+" is added to inventory");
    }

    public void removeProduct(T product){
        if(products.remove(product)){
            System.out.println(product.getName()+" removed successfully");
        }
        else{
            System.out.println(product.getName()+" is not found in inventory");
        }
    }

    public void listproducts(){
        if(products.isEmpty())
         System.out.println("No products in inventory");
        else{
            System.out.println("Products in inventory:");
            for(T prod : products){
                System.out.println(prod.getName());
            }
        } 
    }
}

public class Q1 {
    public static void main(String[] args) {
        Inventory<product> inventory=new Inventory<>();
        Electronics phone=new Electronics("Apple",10);
        Clothing shirt=new Clothing("Raymonds","32");
        inventory.addProduct(phone);
        inventory.addProduct(shirt);
        inventory.listproducts();
        inventory.removeProduct(phone);
        inventory.listproducts();
    }
}
