
class Vehicle{
    private String type;

    public Vehicle(String type){
        this.type=type;
    }

    public void start(){
        System.out.println("Starting a Vehicle");
    }
}

class Car extends Vehicle {
    private String model;

    public Car(String type,String model){
        super(type);
        this.model=model;
    }

    @Override
    public void start(){
        super.start();
        System.out.println("Starting a Car..model: "+ model);
    }
}

class ElectricCar extends Car{
    private int batterycapacity;

    public ElectricCar(String type,String model,int batterycapacity){
        super(type,model);
        this.batterycapacity=batterycapacity;
    }
        
    @Override
    public void start(){
        super.start();
        System.out.println("Starting a Electric Car..battery Capacity: "+ batterycapacity);
    }   
}

class Tesla extends ElectricCar{
    private String autopilotVersion;

    public Tesla(String type, String model, int batteryCapacity, String autopilotVersion) {
        super(type, model, batteryCapacity);  
        this.autopilotVersion = autopilotVersion;
    }

    @Override
    public void start() {
        super.start();  
        System.out.println("Starting the Tesla... Autopilot Version: " + autopilotVersion);
    }
}

public class Q6 {
    public static void main(String[] args) {
        Tesla t1 = new Tesla("Electric Vehicle", "Model S", 100, "2.0");
        t1.start();
    }
}
