class Employee {
    private String name;
    private double Salary;
    private int age;
    static int employeecount=0;

    public Employee(String name,double Salary,int age){
        this.name=name;
        this.Salary=Salary;
        this.age=age;
        ++employeecount; 
    }

    public String getName(){
        return name;
    }

    public double getSalary(){
        return Salary;
    }

    public int getAge(){
        return age;
    }

    public void raiseSalary(double in){
        this.Salary+=in;
    }

    public void displayInfo(){
        System.out.println("Name :"+name);
        System.out.println("Salary :"+Salary);
        System.out.println("Age :"+age);
    }

    public static int getEmployeecount(){
        return employeecount;
    } 
}

class Analyst extends Employee {
    private String Specialization;

    public Analyst(String name,double Salary,int age,String Specialization){
        super(name,Salary,age);
        this.Specialization=Specialization;
    }

    public void displayAnalystInfo(){
        super.displayInfo();
        System.out.println("Specialization :"+Specialization);
    }
}

class Salesperson extends Employee {
    private String region;

    public Salesperson(String name,double Salary,int age,String region){
        super(name,Salary,age);
        this.region=region;
    }

    public void displaySalespersonInfo(){
        super.displayInfo();
        System.out.println("Region :"+region);
    }
}

public class Q3 {
    public static void main(String[] args) {
        Employee e1=new Employee("John", 50000, 30);
        Analyst a1=new Analyst("Alice", 60000,28,"Data Analysis");
        Salesperson s1=new Salesperson("Bob", 45000, 32,"Northwest");

        System.out.println("\nEmployee Info:");
        e1.displayInfo();
        System.out.println("\nAnalyst Info:");
        a1.displayAnalystInfo();
        System.out.println("\nSalesperson Info:");
        s1.displaySalespersonInfo();

        e1.raiseSalary(18000);
        a1.raiseSalary(66000);
        s1.raiseSalary(10000);

        System.out.println("\nAfter raise in Employee Info:");
        e1.displayInfo();
        System.out.println("\nAfter raise in Analyst Info:");
        a1.displayAnalystInfo();
        System.out.println("\nAfter raise in Salesperson Info:");
        s1.displaySalespersonInfo();

        System.out.println("\nTotal Employees :"+Employee.getEmployeecount());
    }
}
