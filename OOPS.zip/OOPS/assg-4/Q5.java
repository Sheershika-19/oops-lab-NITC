class Animal {
    private String name;

    public Animal(String name){
        this.name=name;
    }

    public void sound(){
        System.out.println("Animal Sound called");
        System.out.println("Name :"+name);
    }
}

class Mammal extends Animal{
    private int age;

    public Mammal(String name,int age){
        super(name);
        this.age=age;
    }

    @Override
    public void sound(){
        super.sound();
        System.out.println("Mammal sound called");
        System.out.println("Age :"+age);
    }
}

class Dog extends Mammal {
    private String breed;

    public Dog(String name,int age,String breed){
        super(name,age);
        this.breed=breed;
    }

    @Override
    public void sound(){
        super.sound();
        System.out.println("Dog sound called");
        System.out.println("Breed :"+breed);
    }
}

class Puppy extends Dog{
    private String NickName;

    public Puppy(String name,int age,String breed,String NickName){
        super(name,age,breed);
        this.NickName=NickName;
    }

    @Override
    public void sound(){
        super.sound();
        System.out.println("Puppy sound called");
        System.out.println("Nick Name :"+NickName);
    }

}


public class Q5 {
    public static void main(String[] args) {
        Puppy pp=new Puppy("Buddy", 4, "Golden Retriever", "Say");
        pp.sound();
    }
}
