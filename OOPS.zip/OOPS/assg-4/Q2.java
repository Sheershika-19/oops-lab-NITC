import java.util.ArrayList;
import java.util.List;

class Entity{
    private String name;

    public Entity(String name){
        this.name=name;
    }

    public String getName(){
        return name;
    }

    @Override
    public String toString(){
        return "Entity :"+name;
    }
}

class Employee extends Entity{
    public Employee(String name){
        super(name);
    }

    @Override
    public String toString(){
        return "Employee :"+getName();
    }
}

class Manager extends Employee {
    public Manager(String name){
        super(name);
    }

    @Override
    public String toString(){
        return "Manager :"+getName();
    }
}

class HierarchicalManger<T extends Entity> {
    private List<T> entities;

    public HierarchicalManger(){
        entities=new ArrayList<>();
    }

    public void addEntity(T entity){
        entities.add(entity);
        System.out.println(entity.getName()+" is added to hierarchy.");
    }

    public void removeEntity(T entity){
        if(entities.remove(entity)){
            System.out.println(entity.getName()+" is removed from hierarchy.");
        }
        else{
            System.out.println(entity.getName()+" is not present in hierarchy.");
        }
    }

    public List<T> getAllEntities(){
        return new ArrayList<>(entities);
    }

    public List<T> getEntitiesByType(Class<?> type) {
        List<T> result = new ArrayList<>();
        for (T entity : entities) {
            if (type.isInstance(entity)) {
                result.add(entity);
            }
        }
        return result;
    }

    public void printHierarchy() {
        if (entities.isEmpty()) {
            System.out.println("No entities in the hierarchy.");
        } else {
            System.out.println("Hierarchy:");
            for (T entity : entities) {
                System.out.println(entity + " (" + entity.getClass().getSimpleName() + ")");
            }
        }
    }

}

public class Q2 {
    public static void main(String[] args) {
        HierarchicalManger<Entity> manager=new HierarchicalManger<>();
        Employee e1=new Employee("Ram");
        Manager m1=new Manager("Sheershika");
        Manager m2=new Manager("Bob");
        manager.addEntity(e1);
        manager.addEntity(m1);
        manager.addEntity(m2);
        manager.printHierarchy();
        System.out.println("Managers in the hierarchy:");
        for (Entity entity : manager.getEntitiesByType(Manager.class)) {
            System.out.println(entity);
        }
        manager.removeEntity(m1);
        manager.printHierarchy();
    }
}
