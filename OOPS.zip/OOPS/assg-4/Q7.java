class Employee {
    private String name;
    private double Salary;

    public Employee(String name,double Salary){
        this.name=name;
        this.Salary=Salary;
    }

    public void displayDetails(){
        System.out.println("Name :"+name+" ,Salary :"+Salary);
    }
}

class Manager extends Employee{
    private String departmentName;

    public Manager(String name,double Salary,String departmentName){
        super(name,Salary);
        this.departmentName=departmentName;
    }

    @Override
    public void displayDetails(){
      super.displayDetails();
      System.out.println("Department Name :"+departmentName+"\n"); 
      
    }
}

class Developer extends Employee{
    private String programmingLanguage;

    public Developer(String name,double Salary,String programmingLanguage){
        super(name,Salary);
        this.programmingLanguage=programmingLanguage;
    }

    @Override
    public void displayDetails(){
      super.displayDetails();
      System.out.println("Programming Language :"+programmingLanguage+"\n"); 
      
    }
}

public class Q7 {
    public static void main(String[] args) {
        Manager m1=new Manager("Devansh",50000,"Finance");
        System.out.println("Manger details:");
        m1.displayDetails();
        Developer d1=new Developer("Sheershika", 200000, "Java");
        System.out.println("Developer details:");
        d1.displayDetails();
    }
}
