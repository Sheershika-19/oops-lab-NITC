import java.util.ArrayList;
import java.util.List;

/*Aggregation in Java is a design concept that represents a "has-a" relationship between two classes
 but with a weaker association compared to composition. In aggregation, one class contains a reference
  to another class,
 but unlike composition, the lifecycle of the contained object is independent of the container object. */

class Book {
    private String title;
    private String authorName;
    private int publicationYear;

    public Book(String title,String authorName,int publicationYear){
        this.title=title;
        this.authorName=authorName;
        this.publicationYear=publicationYear;
   }

   public String getTitle(){
    return title;
   }

   public String getauthorName(){
    return authorName;
   }

   public int getpublicationYear(){
    return publicationYear;
   }

   public void displayBookInfo() {
    System.out.println("Title: " + title + ", Author: " + authorName + ", Publication Year: " + publicationYear);
   }
}

class Library{
    private List<Book> books;

    public Library(){
        books=new ArrayList<>();
    }

    public void addBook(Book book){
        books.add(book);
        System.out.println("Book Added: "+book.getTitle());
    }

    public void removeBook(Book book){       
            books.remove(book);
            System.out.println("Removed Book: "+book.getTitle());
    }

    public void displayBooks(){
        if(books.isEmpty())
          System.out.println("Library is Empty");
        else{
            System.out.println("Books in Library:");
            for(Book book:books){
                book.displayBookInfo();
            }
        }  
    }
}

public class Q8 {
    public static void main(String[] args) {
        Library lib =new Library();
        
        Book book1=new Book("Alice in wonderland","Alice",1988);
        Book book2=new Book("To kill a mocking bird","Harper lee",1960);
        Book book3=new Book("The Great Gatsby", "F. Scott Fitzgerald", 1925);
        lib.addBook(book1);
        lib.addBook(book2);
        lib.addBook(book3);

        lib.displayBooks();
        lib.removeBook(book3);
        lib.displayBooks();
    }
}
