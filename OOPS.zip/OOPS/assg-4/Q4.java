import java.util.ArrayList;
import java.util.List;

class Author{
    private String name;
    private String nationality;

    public Author(String name,String nationality){
        this.name=name;
        this.nationality=nationality;
    }

    public String getName(){
        return name;
    }

    public String  getNationality(){
        return nationality;
    }

    public void displayAuthorInfo(){
        System.out.println("Author :"+name+", "+"Nationality :"+nationality);
    }
}

class Book{
    private String title;
    private String isbn;
    private Author author;

    public Book(String title,String isbn,Author author){
        this.title=title;
        this.isbn=isbn;
        this.author=author;
    }

    public String getTitle(){
        return title;
    }

    public String getisbn(){
        return isbn;
    }

    public void displayBookInfo(){
        System.out.println("Title :"+title+" ,"+"ISBN :"+isbn);
        author.displayAuthorInfo();
    }
}

class Library{
    private List<Book> books=new ArrayList<>();
    
    public Library(){
        books=new ArrayList<>();
    }

    public void addBook(Book book){
        books.add(book);
        System.out.println(book.getTitle()+" is added to Library\n");
    }

    public void displayBooks(){
        if(books.isEmpty())
         System.out.println("Library has no books");
        else {
            for(Book book :books){
                book.displayBookInfo();
                System.out.println("\n");
            }
        } 
    }
}

public class Q4 {
    public static void main(String[] args) {
        Library lib=new Library();
        Author author1 = new Author("George Orwell", "British");
        Book book1 = new Book("1984", "1234567890", author1);
        Author author2 = new Author("F. Scott Fitzgerald", "American");
        Book book2 = new Book("The Great Gatsby", "0987654321", author2);
        lib.addBook(book1);
        lib.addBook(book2);
        lib.displayBooks();
    }
}
